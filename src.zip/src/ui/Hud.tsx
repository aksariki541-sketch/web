import { useEffect, useState } from 'react';
import { CONFIG, ROOMS, RoomId } from '../world/config';
import type { Quality } from '../world/config';

/* ============ small atoms ============ */
export function IconButton({
  label,
  active,
  onClick,
  children,
}: {
  label: string;
  active?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      title={label}
      aria-label={label}
      onClick={onClick}
      className={`group relative flex h-10 w-10 items-center justify-center border transition-all duration-300 ${
        active
          ? 'border-[#d4af37] bg-[#d4af37]/15 text-[#f5d76e]'
          : 'border-white/15 bg-black/50 text-white/60 hover:border-[#d4af37]/70 hover:text-[#f5d76e]'
      }`}
      style={active ? { boxShadow: '0 0 18px rgba(212,175,55,0.35)' } : undefined}
    >
      {children}
      <span className="pointer-events-none absolute -bottom-6 right-0 whitespace-nowrap text-[8px] tracking-[0.2em] text-white/0 transition-colors duration-300 group-hover:text-white/45">
        {label}
      </span>
    </button>
  );
}

/* ============ HUD ============ */
type HudProps = {
  roomName: string;
  room: RoomId;
  prompt: { title: string; action: string } | null;
  isMobile: boolean;
  sound: boolean;
  fps: number;
  quality: Quality;
  secretUnlocked: boolean;
  cinematic: boolean;
  onToggleSound: () => void;
  onToggleSettings: () => void;
  onToggleMenu: () => void;
  onFullscreen: () => void;
  menuOpen: boolean;
  settingsOpen: boolean;
};

export function Hud(p: HudProps) {
  return (
    <>
      {/* cinematic letterbox */}
      <div
        className="pointer-events-none fixed inset-x-0 top-0 z-20 bg-gradient-to-b from-black/80 to-transparent transition-all duration-700"
        style={{ height: p.cinematic ? 110 : 80 }}
      />
      <div
        className="pointer-events-none fixed inset-x-0 bottom-0 z-20 bg-gradient-to-t from-black/85 to-transparent transition-all duration-700"
        style={{ height: p.cinematic ? 120 : 90 }}
      />
      <div
        className="pointer-events-none fixed inset-0 z-20"
        style={{ boxShadow: 'inset 0 0 220px rgba(0,0,0,0.9)' }}
      />

      {/* TOP LEFT — brand + location */}
      <div className="anim-fade-up pointer-events-none fixed left-5 top-5 z-30 flex items-center gap-4 sm:left-8 sm:top-7">
        <div className="relative h-11 w-11">
          <div className="absolute inset-0 rotate-45 border border-[#d4af37]/70" />
          <div className="anim-spin-slow absolute inset-1.5 rounded-full border border-dashed border-[#d4af37]/40" />
          <div className="absolute inset-0 flex items-center justify-center text-[#f5d76e]">◆</div>
        </div>
        <div>
          <div className="tracked text-[13px] leading-none text-white text-shadow-gold">{CONFIG.brand}</div>
          <div className="mt-1.5 flex items-center gap-2">
            <span className="anim-pulse h-1 w-1 rounded-full bg-[#d4af37]" />
            <span className="tracked-sm text-[9px] text-[#d4af37]">{p.roomName}</span>
          </div>
        </div>
      </div>

      {/* TOP RIGHT — system controls */}
      <div className="fixed right-5 top-5 z-30 flex items-center gap-2 sm:right-8 sm:top-7">
        <div className="mr-2 hidden flex-col items-end sm:flex">
          <span className="tracked-sm text-[9px] text-white/40">{p.fps} FPS</span>
          <span className="tracked-sm text-[9px] text-[#d4af37]/70">{p.quality.toUpperCase()}</span>
        </div>
        <IconButton label="SOUND" active={p.sound} onClick={p.onToggleSound}>
          {p.sound ? (
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M4 9v6h4l5 4V5L8 9H4z" />
              <path d="M17 8.5a5 5 0 0 1 0 7" />
            </svg>
          ) : (
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M4 9v6h4l5 4V5L8 9H4z" />
              <path d="M17 9l4 6M21 9l-4 6" />
            </svg>
          )}
        </IconButton>
        <IconButton label="SETTINGS" active={p.settingsOpen} onClick={p.onToggleSettings}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <circle cx="12" cy="12" r="3" />
            <path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1" />
          </svg>
        </IconButton>
        <IconButton label="FULLSCREEN" onClick={p.onFullscreen}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />
          </svg>
        </IconButton>
        <IconButton label="MENU" active={p.menuOpen} onClick={p.onToggleMenu}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M4 7h16M4 12h16M4 17h16" />
          </svg>
        </IconButton>
      </div>

      {/* BOTTOM CENTER — interaction prompt */}
      <div className="pointer-events-none fixed bottom-28 left-1/2 z-30 -translate-x-1/2 sm:bottom-24">
        {p.prompt && (
          <div className="anim-pop glass corner-frame flex items-center gap-4 px-6 py-3">
            <span className="flex h-7 min-w-7 items-center justify-center border border-[#d4af37] px-2 text-[10px] font-semibold text-[#f5d76e]">
              {p.isMobile ? '⊙' : 'E'}
            </span>
            <div className="leading-tight">
              <div className="tracked-sm text-[11px] text-white">{p.prompt.title}</div>
              <div className="text-[9px] tracking-[0.3em] text-[#d4af37]">{p.prompt.action}</div>
            </div>
          </div>
        )}
      </div>

      {/* BOTTOM LEFT — desktop control hints */}
      {!p.isMobile && (
        <div className="pointer-events-none fixed bottom-6 left-8 z-30 hidden gap-6 text-[9px] tracking-[0.22em] text-white/35 lg:flex">
          {[
            ['W A S D', 'MOVE'],
            ['SHIFT', 'RUN'],
            ['SPACE', 'JUMP'],
            ['E', 'INTERACT'],
            ['ESC', 'MENU'],
            ['DRAG', 'CAMERA'],
          ].map(([k, v]) => (
            <div key={k} className="flex items-center gap-2">
              <span className="border border-white/15 px-2 py-1 text-[#d4af37]">{k}</span>
              <span>{v}</span>
            </div>
          ))}
        </div>
      )}

      {/* BOTTOM RIGHT — mini map */}
      <MiniMap room={p.room} secretUnlocked={p.secretUnlocked} isMobile={p.isMobile} />
    </>
  );
}

/* ============ MINI MAP ============ */
function MiniMap({ room, secretUnlocked, isMobile }: { room: RoomId; secretUnlocked: boolean; isMobile: boolean }) {
  if (isMobile) return null;
  return (
    <div className="pointer-events-none fixed bottom-6 right-8 z-30 hidden h-32 w-32 md:block">
      <div className="absolute inset-0 rounded-full border border-[#d4af37]/25" />
      <div className="anim-spin-slow absolute inset-2 rounded-full border border-dashed border-[#d4af37]/15" />
      {ROOMS.map((r) => {
        if (r.hidden && !secretUnlocked) return null;
        const a = (-r.angle * Math.PI) / 180;
        const d = r.id === 'hub' ? 0 : 42;
        const x = 50 + Math.cos(a) * d;
        const y = 50 + Math.sin(a) * d;
        const active = r.id === room;
        return (
          <div
            key={r.id}
            className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-500"
            style={{ left: `${x}%`, top: `${y}%` }}
          >
            <div
              className={`h-1.5 w-1.5 rotate-45 ${active ? 'bg-[#f5d76e]' : 'bg-[#d4af37]/40'}`}
              style={active ? { boxShadow: '0 0 12px rgba(245,215,110,0.9)' } : undefined}
            />
          </div>
        );
      })}
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-[8px] tracking-[0.2em] text-white/30">NEXUS MAP</span>
      </div>
    </div>
  );
}

/* ============ RADIAL MENU ============ */
export function RadialMenu({
  open,
  current,
  secretUnlocked,
  onSelect,
  onClose,
}: {
  open: boolean;
  current: RoomId;
  secretUnlocked: boolean;
  onSelect: (id: RoomId) => void;
  onClose: () => void;
}) {
  const items = ROOMS.filter((r) => !r.hidden || secretUnlocked);
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    if (open) setMounted(true);
  }, [open]);
  if (!open && !mounted) return null;

  return (
    <div
      className={`fixed inset-0 z-40 flex items-center justify-center transition-all duration-500 ${
        open ? 'pointer-events-auto opacity-100 backdrop-blur-md' : 'pointer-events-none opacity-0'
      }`}
      style={{ background: 'radial-gradient(circle at 50% 50%, rgba(5,5,5,0.65), rgba(0,0,0,0.92))' }}
      onClick={onClose}
    >
      <div className="relative h-[min(78vw,520px)] w-[min(78vw,520px)]" onClick={(e) => e.stopPropagation()}>
        <div className="anim-spin-slow absolute inset-0 rounded-full border border-[#d4af37]/20" />
        <div className="anim-spin-rev absolute inset-10 rounded-full border border-dashed border-[#d4af37]/15" />
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="tracked text-[10px] text-[#d4af37]">NAVIGATION</div>
          <div className="mt-2 tracked text-2xl text-white text-shadow-gold">{CONFIG.brand}</div>
          <div className="mt-2 text-[9px] tracking-[0.3em] text-white/40">SELECT DESTINATION</div>
          <button
            onClick={onClose}
            className="mt-6 border border-white/15 px-5 py-2 text-[9px] tracking-[0.3em] text-white/50 transition hover:border-[#d4af37] hover:text-[#f5d76e]"
          >
            RESUME
          </button>
        </div>
        {items.map((r, i) => {
          const a = (i / items.length) * Math.PI * 2 - Math.PI / 2;
          const x = 50 + Math.cos(a) * 40;
          const y = 50 + Math.sin(a) * 40;
          const active = r.id === current;
          return (
            <button
              key={r.id}
              onClick={() => onSelect(r.id)}
              className="group absolute -translate-x-1/2 -translate-y-1/2"
              style={{
                left: `${x}%`,
                top: `${y}%`,
                animation: open ? `popIn 0.5s cubic-bezier(0.22,1,0.36,1) ${i * 0.06}s both` : undefined,
              }}
            >
              <div
                className={`flex h-20 w-20 flex-col items-center justify-center border transition-all duration-300 sm:h-24 sm:w-24 ${
                  active
                    ? 'border-[#f5d76e] bg-[#d4af37]/20'
                    : 'border-[#d4af37]/30 bg-black/70 hover:border-[#f5d76e] hover:bg-[#d4af37]/10'
                }`}
                style={{
                  boxShadow: active
                    ? '0 0 32px rgba(212,175,55,0.5)'
                    : '0 0 20px rgba(212,175,55,0.12)',
                  clipPath: 'polygon(18% 0, 100% 0, 100% 82%, 82% 100%, 0 100%, 0 18%)',
                }}
              >
                <span className="text-lg text-[#f5d76e] transition-transform duration-300 group-hover:scale-125">
                  {r.icon}
                </span>
                <span className="mt-1.5 text-[8px] tracking-[0.2em] text-white/85">{r.name}</span>
                <span className="mt-0.5 text-[6px] tracking-[0.15em] text-[#d4af37]/70">{r.tag}</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ============ SETTINGS ============ */
export function SettingsPanel({
  open,
  quality,
  sound,
  onQuality,
  onSound,
  onClose,
}: {
  open: boolean;
  quality: Quality;
  sound: boolean;
  onQuality: (q: Quality) => void;
  onSound: (v: boolean) => void;
  onClose: () => void;
}) {
  if (!open) return null;
  return (
    <div className="anim-pop glass-strong fixed right-5 top-20 z-40 w-72 p-6 sm:right-8 sm:top-24">
      <div className="mb-5 flex items-center justify-between">
        <span className="tracked-sm text-[10px] text-[#d4af37]">SYSTEM SETTINGS</span>
        <button onClick={onClose} className="text-white/40 transition hover:text-[#f5d76e]">
          ✕
        </button>
      </div>

      <div className="mb-6">
        <div className="mb-3 text-[9px] tracking-[0.28em] text-white/45">GRAPHICS QUALITY</div>
        <div className="grid grid-cols-3 gap-2">
          {(['low', 'medium', 'high'] as Quality[]).map((q) => (
            <button
              key={q}
              onClick={() => onQuality(q)}
              className={`border py-2 text-[9px] tracking-[0.2em] transition-all duration-300 ${
                quality === q
                  ? 'border-[#d4af37] bg-[#d4af37]/15 text-[#f5d76e]'
                  : 'border-white/12 text-white/50 hover:border-[#d4af37]/60'
              }`}
            >
              {q.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      <div className="mb-6 flex items-center justify-between">
        <span className="text-[9px] tracking-[0.28em] text-white/45">AUDIO</span>
        <button
          onClick={() => onSound(!sound)}
          className={`relative h-6 w-12 border transition-colors duration-300 ${
            sound ? 'border-[#d4af37] bg-[#d4af37]/20' : 'border-white/15 bg-black/60'
          }`}
        >
          <span
            className={`absolute top-1/2 h-4 w-4 -translate-y-1/2 bg-[#d4af37] transition-all duration-300 ${
              sound ? 'left-7' : 'left-1 bg-white/30'
            }`}
          />
        </button>
      </div>

      <div className="space-y-2 border-t border-white/10 pt-4 text-[9px] leading-relaxed tracking-[0.14em] text-white/35">
        <p>PERFORMANCE MODE ENGAGES AUTOMATICALLY IF FRAMERATE DROPS BELOW 34 FPS.</p>
        <p className="text-[#d4af37]/60">TIP: SOMETHING UNDOCUMENTED FLOATS NEAR THE NORTH PILLARS OF THE HUB.</p>
      </div>
    </div>
  );
}
