import { useEffect, useState } from 'react';
import { CONFIG } from '../world/config';
import { ABOUT_PANELS, CONTACTS, NPC_DIALOG, SECRET_TEXT, type Project } from '../world/content';

export type PanelData = { kind: string; id: string; title: string; payload: unknown } | null;

/* ---------- shared shell ---------- */
function Shell({
  eyebrow,
  title,
  children,
  onClose,
  wide,
}: {
  eyebrow: string;
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  return (
    <div className="anim-pop pointer-events-auto relative w-full" style={{ maxWidth: wide ? 880 : 620 }}>
      <div className="glass-strong corner-frame relative overflow-hidden">
        {/* scanline */}
        <div
          className="pointer-events-none absolute inset-x-0 h-24 opacity-[0.07]"
          style={{
            background: 'linear-gradient(180deg, transparent, #f5d76e, transparent)',
            animation: 'scanline 6s linear infinite',
          }}
        />
        <div className="relative flex items-start justify-between border-b border-[#d4af37]/25 px-7 py-5 sm:px-9">
          <div>
            <div className="tracked-sm text-[9px] text-[#d4af37]">{eyebrow}</div>
            <h2 className="mt-2 text-xl font-light tracking-[0.14em] text-white text-shadow-gold sm:text-2xl">
              {title}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="ml-6 flex h-9 w-9 shrink-0 items-center justify-center border border-white/15 text-white/50 transition hover:border-[#d4af37] hover:text-[#f5d76e]"
          >
            ✕
          </button>
        </div>
        <div className="scroll-thin max-h-[62vh] overflow-y-auto px-7 py-6 sm:px-9 sm:py-7">{children}</div>
        <div className="flex items-center justify-between border-t border-[#d4af37]/20 px-7 py-3 text-[8px] tracking-[0.28em] text-white/30 sm:px-9">
          <span>{CONFIG.brand} · NEXUS TERMINAL</span>
          <span className="text-[#d4af37]/60">PRESS ESC TO CLOSE</span>
        </div>
      </div>
    </div>
  );
}

const GoldButton = ({
  children,
  onClick,
  href,
  busy,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  href?: string;
  busy?: boolean;
}) => {
  const cls =
    'group relative inline-flex items-center justify-center overflow-hidden border border-[#d4af37]/60 bg-black/50 px-7 py-3 text-[10px] tracking-[0.3em] text-white transition-all duration-400 hover:border-[#f5d76e] hover:bg-[#d4af37]/12 hover:tracking-[0.38em]';
  const inner = (
    <>
      <span className="relative z-10">{busy ? 'TRANSMITTING…' : children}</span>
      <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-[#d4af37]/30 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
    </>
  );
  return href ? (
    <a href={href} target="_blank" rel="noreferrer" className={cls}>
      {inner}
    </a>
  ) : (
    <button onClick={onClick} className={cls} disabled={busy}>
      {inner}
    </button>
  );
};

/* ---------- typing text ---------- */
function Typed({ text, speed = 14 }: { text: string; speed?: number }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    setN(0);
    const id = setInterval(() => setN((v) => (v >= text.length ? (clearInterval(id), v) : v + 1)), speed);
    return () => clearInterval(id);
  }, [text, speed]);
  return (
    <span>
      {text.slice(0, n)}
      {n < text.length && <span className="anim-pulse text-[#d4af37]">▌</span>}
    </span>
  );
}

/* ---------- contact form ---------- */
function ContactForm() {
  const [state, setState] = useState<'idle' | 'sending' | 'sent'>('idle');
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const field =
    'w-full border border-white/12 bg-black/50 px-4 py-3 text-[12px] tracking-[0.06em] text-white placeholder-white/25 outline-none transition focus:border-[#d4af37] focus:bg-[#d4af37]/5';
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="space-y-3">
        {CONTACTS.map((c) => (
          <a
            key={c.id}
            href={c.href}
            target="_blank"
            rel="noreferrer"
            className="group flex items-center justify-between border border-white/10 bg-black/40 px-4 py-3 transition hover:border-[#d4af37]/70 hover:bg-[#d4af37]/8"
          >
            <span className="text-[9px] tracking-[0.26em] text-[#d4af37]">{c.label}</span>
            <span className="text-[11px] text-white/70 transition group-hover:text-white">{c.value}</span>
          </a>
        ))}
        <p className="pt-2 text-[10px] leading-relaxed tracking-[0.12em] text-white/40">
          Signals are routed through the nexus and answered personally. Average response: 24 hours.
        </p>
      </div>
      <form
        className="space-y-3"
        onSubmit={(e) => {
          e.preventDefault();
          setState('sending');
          setTimeout(() => setState('sent'), 1600);
        }}
      >
        <input
          className={field}
          placeholder="NAME"
          required
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
        <input
          className={field}
          type="email"
          placeholder="EMAIL"
          required
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <textarea
          className={`${field} h-28 resize-none`}
          placeholder="MESSAGE"
          required
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
        />
        {state === 'sent' ? (
          <div className="anim-pop border border-[#d4af37]/60 bg-[#d4af37]/10 px-4 py-3 text-[10px] tracking-[0.24em] text-[#f5d76e]">
            ✦ TRANSMISSION RECEIVED — THANK YOU
          </div>
        ) : (
          <GoldButton busy={state === 'sending'}>SEND SIGNAL</GoldButton>
        )}
      </form>
    </div>
  );
}

/* ---------- NPC dialog ---------- */
function NpcDialog({ onClose }: { onClose: () => void }) {
  const [i, setI] = useState(0);
  const last = i >= NPC_DIALOG.length - 1;
  return (
    <div>
      <div className="mb-6 flex gap-5">
        <div className="relative h-16 w-16 shrink-0">
          <div className="absolute inset-0 rounded-full border border-[#d4af37]/50" />
          <div className="anim-spin-slow absolute inset-2 rounded-full border border-dashed border-[#d4af37]/40" />
          <div className="absolute inset-0 flex items-center justify-center text-2xl text-[#f5d76e]">◉</div>
        </div>
        <p className="min-h-24 text-[13px] leading-relaxed tracking-[0.06em] text-white/80">
          <Typed text={NPC_DIALOG[i]} />
        </p>
      </div>
      <div className="flex items-center gap-4">
        <GoldButton onClick={() => (last ? onClose() : setI(i + 1))}>{last ? 'END TRANSMISSION' : 'CONTINUE'}</GoldButton>
        <span className="text-[9px] tracking-[0.24em] text-white/30">
          {i + 1} / {NPC_DIALOG.length}
        </span>
      </div>
    </div>
  );
}

/* ---------- MAIN ---------- */
export default function Panels({ data, onClose }: { data: PanelData; onClose: () => void }) {
  useEffect(() => {
    if (!data) return;
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [data, onClose]);

  if (!data) return null;
  const { kind, id, title, payload } = data;

  let body: React.ReactNode = null;
  let eyebrow = 'NEXUS RECORD';
  let heading = title;
  let wide = false;

  if (kind === 'npc') {
    eyebrow = 'GUIDE UNIT · V-01';
    body = <NpcDialog onClose={onClose} />;
  } else if (kind === 'project') {
    const p = payload as Project;
    eyebrow = `PROJECT DOSSIER · ${p.year}`;
    wide = true;
    body = (
      <div className="grid gap-7 md:grid-cols-[1.4fr_1fr]">
        <div>
          <p className="text-[13px] leading-relaxed tracking-[0.05em] text-white/75">{p.long}</p>
          <div className="mt-6 flex flex-wrap gap-2">
            {p.tech.map((t) => (
              <span key={t} className="border border-[#d4af37]/45 px-3 py-1.5 text-[9px] tracking-[0.2em] text-[#f5d76e]">
                {t}
              </span>
            ))}
          </div>
          <div className="mt-7 flex flex-wrap gap-3">
            <GoldButton href={p.link}>VISIT PROJECT</GoldButton>
            <GoldButton onClick={onClose}>RETURN TO GALLERY</GoldButton>
          </div>
        </div>
        <div className="relative min-h-44 overflow-hidden border border-[#d4af37]/25 bg-black/60">
          <div
            className="absolute inset-0"
            style={{ background: 'radial-gradient(circle at 50% 40%, rgba(212,175,55,0.22), transparent 65%)' }}
          />
          <div className="anim-float absolute inset-0 flex items-center justify-center">
            <div className="anim-spin-slow h-24 w-24 rotate-45 border border-[#d4af37]/70" />
            <div className="absolute h-16 w-16 rounded-full border border-[#f5d76e]/70" />
            <div className="absolute text-[9px] tracking-[0.24em] text-white/50">{p.id.toUpperCase()}</div>
          </div>
          <div className="absolute bottom-3 left-4 text-[8px] tracking-[0.24em] text-[#d4af37]/70">LIVE PREVIEW FEED</div>
        </div>
      </div>
    );
  } else if (kind === 'skill') {
    const s = payload as { name: string; level: number; note: string };
    eyebrow = 'CAPABILITY ANALYSIS';
    body = (
      <div>
        <div className="mb-6">
          <div className="mb-2 flex justify-between text-[10px] tracking-[0.26em]">
            <span className="text-white/50">MASTERY</span>
            <span className="text-[#f5d76e]">{s.level}%</span>
          </div>
          <div className="h-[3px] w-full bg-white/10">
            <div
              className="h-full bg-gradient-to-r from-[#b8860b] to-[#f5d76e] transition-[width] duration-1000"
              style={{ width: `${s.level}%`, boxShadow: '0 0 16px rgba(212,175,55,0.8)' }}
            />
          </div>
        </div>
        <p className="text-[13px] leading-relaxed tracking-[0.05em] text-white/75">{s.note}</p>
      </div>
    );
  } else if (kind === 'milestone') {
    const e = payload as { year: string; role: string; place: string; text: string };
    eyebrow = `TIMELINE · ${e.year}`;
    heading = e.role;
    body = (
      <div>
        <div className="mb-4 text-[10px] tracking-[0.26em] text-[#d4af37]">{e.place}</div>
        <p className="text-[13px] leading-relaxed tracking-[0.05em] text-white/75">{e.text}</p>
      </div>
    );
  } else if (kind === 'secret') {
    eyebrow = 'CLEARANCE LEVEL VII';
    heading = SECRET_TEXT.title;
    body = (
      <div>
        <p className="text-[13px] leading-relaxed tracking-[0.05em] text-white/80">{SECRET_TEXT.body}</p>
        <div className="mt-6 border border-[#d4af37]/40 bg-[#d4af37]/8 px-5 py-4 font-mono text-[11px] text-[#f5d76e]">
          &gt; build things people can walk inside_
        </div>
      </div>
    );
  } else if (kind === 'terminal' && (payload as { form?: boolean })?.form) {
    eyebrow = 'SECURE CHANNEL';
    heading = 'TRANSMIT A SIGNAL';
    wide = true;
    body = <ContactForm />;
  } else if (kind === 'panel' && (payload as { href?: string })?.href) {
    const c = payload as { label: string; value: string; href: string };
    eyebrow = 'DIRECT LINK';
    heading = c.label;
    body = (
      <div>
        <p className="mb-6 text-[15px] tracking-[0.08em] text-white/80">{c.value}</p>
        <GoldButton href={c.href}>OPEN CHANNEL</GoldButton>
      </div>
    );
  } else if (kind === 'panel') {
    const p = (payload as { title: string; subtitle: string; body: string }) ??
      ABOUT_PANELS[0];
    eyebrow = p.subtitle;
    heading = p.title;
    body = <p className="text-[13px] leading-relaxed tracking-[0.05em] text-white/80">{p.body}</p>;
  } else {
    // generic terminals: nexus core, statue, skills core
    const copy: Record<string, { eyebrow: string; text: string }> = {
      'hub-core': {
        eyebrow: 'NEXUS CORE · DIAGNOSTICS',
        text: 'The core suspends the six chambers of the nexus in perfect balance. Every portal you see draws its light from this single point. Status: nominal. Luminance: 94%. Visitors today: you.',
      },
      'about-statue': {
        eyebrow: 'CENTRAL EXHIBIT',
        text: `${CONFIG.owner} — creative engineer, world builder, obsessive about frames that never drop. This faceted effigy rotates once every 25 seconds, one facet for every project shipped.`,
      },
      'skills-core': {
        eyebrow: 'ENERGY CORE · SYNCHRONISATION',
        text: 'Nine disciplines orbit this reactor. Each ring encodes a decade of practice compressed into light. Synchronisation complete — capability matrix unlocked.',
      },
      'contact-terminal': {
        eyebrow: 'SECURE CHANNEL',
        text: 'Channel open. Speak freely.',
      },
    };
    const c = copy[id] ?? { eyebrow: 'NEXUS RECORD', text: 'No additional data recorded for this object.' };
    eyebrow = c.eyebrow;
    body = <p className="text-[13px] leading-relaxed tracking-[0.05em] text-white/80">{c.text}</p>;
  }

  return (
    <div className="pointer-events-none fixed inset-0 z-40 flex items-end justify-center p-4 pb-24 sm:items-center sm:p-8">
      <div
        className="pointer-events-auto absolute inset-0 backdrop-blur-[3px]"
        style={{ background: 'radial-gradient(circle at 50% 50%, rgba(5,5,5,0.35), rgba(0,0,0,0.7))' }}
        onClick={onClose}
      />
      <Shell eyebrow={eyebrow} title={heading} onClose={onClose} wide={wide}>
        {body}
      </Shell>
    </div>
  );
}
