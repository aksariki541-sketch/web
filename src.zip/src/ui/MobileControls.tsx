import { useRef, useState } from 'react';

type Props = {
  onMove: (x: number, y: number) => void;
  onJump: () => void;
  onInteract: () => void;
  onRunChange: (v: boolean) => void;
  onOrbit: (dx: number, dy: number) => void;
  hasPrompt: boolean;
};

export default function MobileControls({ onMove, onJump, onInteract, onRunChange, onOrbit, hasPrompt }: Props) {
  const baseRef = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const [run, setRun] = useState(false);
  // refs so pointer handlers never see stale React state
  const activeRef = useRef(false);
  const camRef = useRef<{ x: number; y: number } | null>(null);
  const runRef = useRef(false);

  const handle = (e: React.PointerEvent | PointerEvent) => {
    const base = baseRef.current;
    if (!base) return;
    const r = base.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    let dx = (e.clientX - cx) / (r.width / 2);
    let dy = (e.clientY - cy) / (r.height / 2);
    const len = Math.hypot(dx, dy);
    if (len > 1) {
      dx /= len;
      dy /= len;
    }
    setKnob({ x: dx * (r.width / 2 - 22), y: dy * (r.height / 2 - 22) });
    onMove(dx, dy);
  };

  const stop = () => {
    activeRef.current = false;
    setKnob({ x: 0, y: 0 });
    onMove(0, 0);
  };

  const Btn = ({
    label,
    sub,
    onDown,
    onUp,
    highlight,
    size = 'h-16 w-16',
  }: {
    label: string;
    sub?: string;
    onDown: () => void;
    onUp?: () => void;
    highlight?: boolean;
    size?: string;
  }) => (
    <button
      type="button"
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
        onDown();
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onUp?.();
      }}
      onPointerCancel={() => onUp?.()}
      onPointerLeave={() => onUp?.()}
      className={`${size} flex select-none flex-col items-center justify-center rounded-full border text-[9px] tracking-[0.18em] transition-all duration-200 active:scale-90 ${
        highlight
          ? 'border-[#f5d76e] bg-[#d4af37]/25 text-[#f5d76e]'
          : 'border-[#d4af37]/45 bg-black/55 text-white/70'
      }`}
      style={{
        boxShadow: highlight ? '0 0 26px rgba(212,175,55,0.5)' : '0 0 16px rgba(212,175,55,0.15)',
        backdropFilter: 'blur(8px)',
        touchAction: 'none',
      }}
    >
      <span className="text-[11px]">{label}</span>
      {sub && <span className="mt-0.5 text-[7px] text-[#d4af37]/80">{sub}</span>}
    </button>
  );

  return (
    <div className="pointer-events-none fixed inset-0 z-30 select-none">
      {/* camera drag pad (upper right half) */}
      <div
        className="pointer-events-auto absolute right-0 top-24 h-[42vh] w-1/2"
        style={{ touchAction: 'none' }}
        onPointerDown={(e) => {
          e.preventDefault();
          (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
          camRef.current = { x: e.clientX, y: e.clientY };
        }}
        onPointerMove={(e) => {
          if (!camRef.current) return;
          onOrbit(e.clientX - camRef.current.x, e.clientY - camRef.current.y);
          camRef.current = { x: e.clientX, y: e.clientY };
        }}
        onPointerUp={() => {
          camRef.current = null;
        }}
        onPointerCancel={() => {
          camRef.current = null;
        }}
      >
        <span className="absolute right-4 top-2 text-[8px] tracking-[0.25em] text-white/20">DRAG · CAMERA</span>
      </div>

      {/* joystick */}
      <div
        ref={baseRef}
        className="pointer-events-auto absolute bottom-8 left-6 h-32 w-32 rounded-full border"
        style={{
          borderColor: activeRef.current || knob.x || knob.y ? 'rgba(245,215,110,0.85)' : 'rgba(212,175,55,0.35)',
          background: 'radial-gradient(circle, rgba(20,20,20,0.55), rgba(5,5,5,0.75))',
          boxShadow:
            activeRef.current || knob.x || knob.y
              ? '0 0 34px rgba(212,175,55,0.45)'
              : '0 0 18px rgba(212,175,55,0.12)',
          backdropFilter: 'blur(6px)',
          transition: 'box-shadow .25s, border-color .25s',
          touchAction: 'none',
        }}
        onPointerDown={(e) => {
          e.preventDefault();
          e.stopPropagation();
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          activeRef.current = true;
          handle(e);
        }}
        onPointerMove={(e) => {
          if (!activeRef.current) return;
          e.preventDefault();
          handle(e);
        }}
        onPointerUp={(e) => {
          e.preventDefault();
          stop();
        }}
        onPointerCancel={stop}
      >
        <div className="absolute inset-3 rounded-full border border-dashed border-[#d4af37]/20" />
        <div
          className="pointer-events-none absolute left-1/2 top-1/2 h-12 w-12 rounded-full border border-[#d4af37]"
          style={{
            transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))`,
            background: 'radial-gradient(circle, rgba(212,175,55,0.35), rgba(5,5,5,0.9))',
            boxShadow: '0 0 22px rgba(212,175,55,0.5)',
            transition: activeRef.current ? 'none' : 'transform .28s cubic-bezier(0.22,1,0.36,1)',
          }}
        />
        <span className="pointer-events-none absolute -top-6 left-1/2 -translate-x-1/2 text-[8px] tracking-[0.25em] text-white/25">
          MOVE
        </span>
      </div>

      {/* action buttons */}
      <div className="pointer-events-auto absolute bottom-8 right-6 flex flex-col items-end gap-3">
        <div className="flex items-end gap-3">
          <Btn
            label="RUN"
            onDown={() => {
              const next = !runRef.current;
              runRef.current = next;
              setRun(next);
              onRunChange(next);
            }}
            highlight={run}
            size="h-14 w-14"
          />
          <Btn label="⤒" sub="JUMP" onDown={onJump} size="h-16 w-16" />
        </div>
        <Btn label="E" sub="INTERACT" onDown={onInteract} highlight={hasPrompt} size="h-20 w-20" />
      </div>
    </div>
  );
}
