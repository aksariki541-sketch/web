import { useEffect, useState } from 'react';
import { CONFIG } from '../world/config';

type Props = {
  progress: number;
  message: string;
  ready: boolean;
  onEnter: () => void;
};

const PARTICLES = Array.from({ length: 34 }, (_, i) => ({
  left: (i * 37) % 100,
  delay: (i % 11) * 0.45,
  dur: 6 + (i % 7),
  size: 1 + (i % 3),
}));

export default function LoadingScreen({ progress, message, ready, onEnter }: Props) {
  const [log, setLog] = useState<string[]>([]);
  useEffect(() => {
    setLog((l) => (l[l.length - 1] === message ? l : [...l, message].slice(-5)));
  }, [message]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden bg-[#050505]">
      {/* ambient gold particles */}
      <div className="pointer-events-none absolute inset-0">
        {PARTICLES.map((p, i) => (
          <span
            key={i}
            className="absolute bottom-0 rounded-full bg-[#f5d76e]"
            style={{
              left: `${p.left}%`,
              bottom: `${6 + ((i * 13) % 78)}vh`,
              width: p.size,
              height: p.size,
              opacity: 0.5,
              animation: `floatY ${p.dur}s ease-in-out ${p.delay}s infinite, fadeIn 2s ease ${p.delay}s both`,
              boxShadow: '0 0 8px rgba(245,215,110,0.9)',
            }}
          />
        ))}
      </div>
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 55%, rgba(212,175,55,0.14), rgba(5,5,5,0) 55%)',
        }}
      />

      {/* rotating gold rings */}
      <div className="relative mb-14 h-52 w-52">
        <div className="anim-spin-slow absolute inset-0 rounded-full border border-[#d4af37]/40" />
        <div className="anim-spin-rev absolute inset-4 rounded-full border border-dashed border-[#d4af37]/30" />
        <div
          className="anim-spin-slow absolute inset-8 rounded-full border-t-2 border-[#f5d76e]"
          style={{ animationDuration: '3.2s' }}
        />
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="tracked text-[11px] text-[#d4af37]">{CONFIG.brand}</div>
          <div className="mt-1 text-4xl font-light tabular-nums text-white text-shadow-gold">
            {Math.round(progress)}
            <span className="text-lg text-[#d4af37]">%</span>
          </div>
        </div>
      </div>

      <div className="w-[min(78vw,540px)]">
        <div className="mb-3 flex items-baseline justify-between">
          <span className="tracked-sm text-[10px] text-white/50">INITIALIZING WORLD</span>
          <span className="tracked-sm text-[10px] text-[#d4af37]">V-01 / NEXUS</span>
        </div>
        <div className="relative h-[3px] w-full overflow-hidden bg-white/10">
          <div
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-[#b8860b] via-[#f5d76e] to-[#d4af37] transition-[width] duration-500 ease-out"
            style={{ width: `${progress}%`, boxShadow: '0 0 18px rgba(212,175,55,0.9)' }}
          />
        </div>
        <div className="mt-6 h-24 space-y-1.5 font-mono text-[10px] leading-relaxed text-white/45">
          {log.map((l, i) => (
            <div key={l + i} className="anim-fade-in flex gap-2">
              <span className="text-[#d4af37]">›</span>
              <span className={i === log.length - 1 ? 'text-white/80' : ''}>{l}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6 h-16">
        {ready && (
          <button
            onClick={onEnter}
            className="anim-pop group relative overflow-hidden border border-[#d4af37]/60 bg-black/60 px-12 py-4 tracked text-[11px] text-white transition-all duration-500 hover:border-[#f5d76e] hover:bg-[#d4af37]/10 hover:tracking-[0.45em]"
            style={{ boxShadow: '0 0 30px rgba(212,175,55,0.25)' }}
          >
            <span className="relative z-10">START EXPERIENCE</span>
            <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-[#d4af37]/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
          </button>
        )}
      </div>

      <div className="absolute bottom-6 tracked-sm text-[9px] text-white/30">
        BLACK · GOLD · WHITE — {CONFIG.brandSub}
      </div>
    </div>
  );
}
