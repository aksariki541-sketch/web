import { useCallback, useEffect, useRef, useState } from 'react';
import { World, type WorldState } from './world/World';
import { CONFIG, ROOMS, type Quality, type RoomId } from './world/config';
import LoadingScreen from './ui/LoadingScreen';
import { Hud, RadialMenu, SettingsPanel } from './ui/Hud';
import MobileControls from './ui/MobileControls';
import Panels, { type PanelData } from './ui/Panels';

const isTouchDevice = () =>
  typeof window !== 'undefined' && (window.matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window);

const guessQuality = (): Quality => {
  if (typeof navigator === 'undefined') return 'high';
  const mem = (navigator as unknown as { deviceMemory?: number }).deviceMemory ?? 8;
  const cores = navigator.hardwareConcurrency ?? 8;
  if (isTouchDevice() && (mem <= 4 || cores <= 4)) return 'low';
  if (isTouchDevice() || mem <= 4 || cores <= 4) return 'medium';
  return 'high';
};

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const worldRef = useRef<World | null>(null);
  const bootedRef = useRef(false);

  const [progress, setProgress] = useState(0);
  const [loadMsg, setLoadMsg] = useState('BOOTING NEXUS...');
  const [ready, setReady] = useState(false);
  const [entered, setEntered] = useState(false);

  const [state, setState] = useState<WorldState>({
    room: 'hub',
    roomName: 'MAIN HUB',
    prompt: null,
    running: false,
    moving: false,
    cinematic: true,
    secretUnlocked: false,
    fps: 60,
  });

  const [panel, setPanel] = useState<PanelData>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [sound, setSound] = useState(true);
  const [quality, setQuality] = useState<Quality>(guessQuality());
  const [flash, setFlash] = useState(0);
  const [toast, setToast] = useState<{ title: string; sub: string; key: number } | null>(null);
  const [mobile] = useState(isTouchDevice());

  /* ---------------- boot the engine ---------------- */
  useEffect(() => {
    if (bootedRef.current || !mountRef.current) return;
    bootedRef.current = true;
    const world = new World();
    worldRef.current = world;
    const q = guessQuality();
    setQuality(q);

    world.onState = (partial) => setState((s) => ({ ...s, ...partial }));
    world.onEvent = (e) => {
      if (e.type === 'open') {
        setPanel({ kind: e.kind, id: e.id, title: e.title, payload: e.payload });
      } else if (e.type === 'flash') {
        setFlash((f) => f + 1);
      } else if (e.type === 'unlock-secret') {
        setFlash((f) => f + 1);
        setToast({ title: 'SECTOR VII UNLOCKED', sub: 'A HIDDEN PORTAL HAS OPENED IN THE HUB', key: Date.now() });
        setPanel({ kind: 'secret', id: 'secret', title: 'SECTOR VII', payload: null });
      } else if (e.type === 'enter-room') {
        const room = ROOMS.find((r) => r.id === e.room);
        if (room) setToast({ title: room.name, sub: room.tag, key: Date.now() });
      }
    };

    world
      .init(mountRef.current, q, (p, msg) => {
        setProgress(p);
        setLoadMsg(msg);
      })
      .then(() => {
        world.start();
        setReady(true);
      });

    return () => {
      world.dispose();
      worldRef.current = null;
      bootedRef.current = false;
    };
  }, []);

  /* ---------------- global keys ---------------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (panel) setPanel(null);
        else {
          setMenuOpen((m) => !m);
          setSettingsOpen(false);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [panel]);

  /* freeze world input while a modal or the radial menu is open */
  useEffect(() => {
    const w = worldRef.current;
    if (!w) return;
    w.setJoystick(0, 0);
    w.setInputEnabled(!panel && !menuOpen && !settingsOpen);
  }, [panel, menuOpen, settingsOpen]);

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 3200);
    return () => clearTimeout(id);
  }, [toast]);

  const enterWorld = useCallback(() => {
    const w = worldRef.current;
    if (!w) return;
    w.audio.start();
    w.audio.setEnabled(true);
    w.startIntro();
    setEntered(true);
    setToast({ title: 'WELCOME TO THE NEXUS', sub: 'MOVE WITH WASD · PRESS E TO INTERACT', key: Date.now() });
  }, []);

  const closePanel = useCallback(() => {
    setPanel(null);
    worldRef.current?.clearFocus();
  }, []);

  const goToRoom = useCallback((id: RoomId) => {
    worldRef.current?.audio.click();
    worldRef.current?.enterRoom(id);
    setMenuOpen(false);
    setPanel(null);
    worldRef.current?.clearFocus();
  }, []);

  const toggleSound = useCallback(() => {
    setSound((s) => {
      worldRef.current?.audio.setEnabled(!s);
      return !s;
    });
  }, []);

  const changeQuality = useCallback((q: Quality) => {
    setQuality(q);
    worldRef.current?.setQuality(q);
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen?.();
    else document.exitFullscreen?.();
  }, []);

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#050505]">
      {/* 3D CONTAINER */}
      <div ref={mountRef} className="absolute inset-0" />

      {/* vignette + grain */}
      <div
        className="pointer-events-none absolute inset-0 z-10 opacity-[0.16]"
        style={{
          backgroundImage:
            'repeating-linear-gradient(0deg, rgba(255,255,255,0.035) 0px, rgba(255,255,255,0.035) 1px, transparent 1px, transparent 3px)',
        }}
      />

      {/* gold portal flash */}
      {flash > 0 && (
        <div
          key={flash}
          className="anim-flash pointer-events-none absolute inset-0 z-40"
          style={{ background: 'radial-gradient(circle at 50% 55%, rgba(245,215,110,0.9), rgba(212,175,55,0.25) 45%, transparent 75%)' }}
        />
      )}

      {entered && (
        <>
          <Hud
            roomName={state.roomName}
            room={state.room}
            prompt={panel || menuOpen ? null : state.prompt}
            isMobile={mobile}
            sound={sound}
            fps={state.fps}
            quality={quality}
            secretUnlocked={state.secretUnlocked}
            cinematic={state.cinematic}
            menuOpen={menuOpen}
            settingsOpen={settingsOpen}
            onToggleSound={toggleSound}
            onToggleSettings={() => setSettingsOpen((s) => !s)}
            onToggleMenu={() => setMenuOpen((m) => !m)}
            onFullscreen={toggleFullscreen}
          />

          {mobile && (
            <MobileControls
              hasPrompt={!!state.prompt}
              onMove={(x, y) => worldRef.current?.setJoystick(x, y)}
              onJump={() => worldRef.current?.jump()}
              onInteract={() => worldRef.current?.interact()}
              onRunChange={(v) => worldRef.current?.setRun(v)}
              onOrbit={(dx, dy) => worldRef.current?.orbit(dx, dy)}
            />
          )}

          <RadialMenu
            open={menuOpen}
            current={state.room}
            secretUnlocked={state.secretUnlocked}
            onSelect={goToRoom}
            onClose={() => setMenuOpen(false)}
          />

          <SettingsPanel
            open={settingsOpen}
            quality={quality}
            sound={sound}
            onQuality={changeQuality}
            onSound={(v) => {
              setSound(v);
              worldRef.current?.audio.setEnabled(v);
            }}
            onClose={() => setSettingsOpen(false)}
          />

          <Panels data={panel} onClose={closePanel} />

          {/* room toast */}
          {toast && (
            <div key={toast.key} className="pointer-events-none fixed inset-x-0 top-1/3 z-30 flex justify-center">
              <div className="anim-fade-up text-center">
                <div className="tracked text-3xl font-extralight text-white text-shadow-gold sm:text-5xl">
                  {toast.title}
                </div>
                <div className="mt-3 flex items-center justify-center gap-3">
                  <span className="h-px w-10 bg-gradient-to-r from-transparent to-[#d4af37]" />
                  <span className="tracked-sm text-[9px] text-[#d4af37]">{toast.sub}</span>
                  <span className="h-px w-10 bg-gradient-to-l from-transparent to-[#d4af37]" />
                </div>
              </div>
            </div>
          )}

          {/* floating quick-nav (desktop) */}
          {!mobile && (
            <div className="fixed left-1/2 top-6 z-30 hidden -translate-x-1/2 items-center gap-1 sm:flex">
              {ROOMS.filter((r) => !r.hidden || state.secretUnlocked).map((r) => (
                <button
                  key={r.id}
                  onClick={() => goToRoom(r.id)}
                  className={`px-4 py-2 text-[9px] tracking-[0.24em] transition-all duration-300 ${
                    state.room === r.id
                      ? 'text-[#f5d76e] text-shadow-gold'
                      : 'text-white/40 hover:text-white/90'
                  }`}
                >
                  {r.name}
                  <span
                    className={`mt-1.5 block h-px transition-all duration-500 ${
                      state.room === r.id ? 'bg-[#d4af37]' : 'bg-transparent'
                    }`}
                  />
                </button>
              ))}
            </div>
          )}
        </>
      )}

      {!entered && (
        <LoadingScreen progress={progress} message={loadMsg} ready={ready} onEnter={enterWorld} />
      )}

      <noscript>
        <div className="p-10 text-white">{CONFIG.brand} requires JavaScript and WebGL.</div>
      </noscript>
    </div>
  );
}
