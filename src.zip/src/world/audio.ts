/* =========================================================================
   AUDIO SYSTEM — 100% synthesized with WebAudio (no external assets)
   ========================================================================= */

export class AudioSystem {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  musicGain: GainNode | null = null;
  ambienceGain: GainNode | null = null;
  enabled = true;
  started = false;
  private noiseBuffer: AudioBuffer | null = null;
  private musicTimer: number | null = null;
  private step = 0;

  start() {
    if (this.started) return;
    try {
      const Ctor =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new Ctor();
    } catch {
      return;
    }
    const ctx = this.ctx!;
    this.master = ctx.createGain();
    this.master.gain.value = this.enabled ? 0.9 : 0;
    this.master.connect(ctx.destination);

    this.musicGain = ctx.createGain();
    this.musicGain.gain.value = 0.0;
    this.musicGain.connect(this.master);

    this.ambienceGain = ctx.createGain();
    this.ambienceGain.gain.value = 0.0;
    this.ambienceGain.connect(this.master);

    // noise buffer for footsteps / whooshes
    const len = ctx.sampleRate * 1.2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    this.noiseBuffer = buf;

    this.buildAmbience();
    this.buildMusic();
    this.started = true;
  }

  private buildAmbience() {
    const ctx = this.ctx!;
    // low drone pad: 3 detuned saw/sine through a lowpass
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 420;
    filter.Q.value = 3;
    filter.connect(this.ambienceGain!);

    [55, 82.4, 110, 164.8].forEach((f, i) => {
      const osc = ctx.createOscillator();
      osc.type = i % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.value = f;
      const g = ctx.createGain();
      g.gain.value = 0.12 / (i + 1);
      // slow LFO on gain to keep the world breathing
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.03 + i * 0.017;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 0.05;
      lfo.connect(lfoGain).connect(g.gain);
      lfo.start();
      osc.connect(g).connect(filter);
      osc.start();
    });

    // airy noise bed
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;
    const nf = ctx.createBiquadFilter();
    nf.type = 'bandpass';
    nf.frequency.value = 900;
    nf.Q.value = 0.6;
    const ng = ctx.createGain();
    ng.gain.value = 0.02;
    src.connect(nf).connect(ng).connect(this.ambienceGain!);
    src.start();

    this.ambienceGain!.gain.linearRampToValueAtTime(0.5, ctx.currentTime + 4);
  }

  private buildMusic() {
    const ctx = this.ctx!;
    this.musicGain!.gain.linearRampToValueAtTime(0.34, ctx.currentTime + 6);
    const scale = [0, 3, 5, 7, 10, 12, 15];
    const root = 220;
    this.musicTimer = window.setInterval(() => {
      if (!this.ctx || !this.enabled) return;
      this.step++;
      if (this.step % 2 === 0) {
        const n = scale[Math.floor(Math.random() * scale.length)];
        this.pluck(root * Math.pow(2, n / 12), 2.4, 0.09);
      }
      if (this.step % 8 === 1) {
        this.pluck(root * 0.5 * Math.pow(2, scale[Math.floor(Math.random() * 3)] / 12), 4.5, 0.07);
      }
    }, 1400);
  }

  private pluck(freq: number, dur: number, vol: number) {
    const ctx = this.ctx!;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, ctx.currentTime);
    g.gain.linearRampToValueAtTime(vol, ctx.currentTime + 0.25);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    const f = ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = 1800;
    osc.connect(f).connect(g).connect(this.musicGain!);
    osc.start();
    osc.stop(ctx.currentTime + dur + 0.1);
  }

  private tone(freq: number, dur: number, vol: number, type: OscillatorType = 'sine', slideTo?: number) {
    if (!this.ctx || !this.enabled) return;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, ctx.currentTime + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(vol, ctx.currentTime + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    osc.connect(g).connect(this.master!);
    osc.start();
    osc.stop(ctx.currentTime + dur + 0.05);
  }

  private noise(dur: number, vol: number, freq: number, q = 1, sweepTo?: number) {
    if (!this.ctx || !this.enabled || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.setValueAtTime(freq, ctx.currentTime);
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, ctx.currentTime + dur);
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    src.connect(f).connect(g).connect(this.master!);
    src.start();
    src.stop(ctx.currentTime + dur + 0.05);
  }

  click() { this.tone(880, 0.09, 0.09, 'triangle', 1320); }
  hover() { this.tone(1440, 0.05, 0.03, 'sine'); }
  step_(running = false) { this.noise(running ? 0.1 : 0.14, running ? 0.09 : 0.06, running ? 260 : 180, 1.4, 90); }
  jump() { this.tone(320, 0.22, 0.08, 'triangle', 720); }
  land() { this.noise(0.18, 0.1, 150, 1, 60); }
  portal() {
    this.tone(180, 1.5, 0.12, 'sawtooth', 900);
    this.noise(1.4, 0.12, 300, 0.7, 2600);
  }
  door() { this.noise(0.9, 0.1, 140, 0.8, 700); this.tone(120, 0.8, 0.07, 'sine', 240); }
  hologram() { this.tone(1200, 0.5, 0.05, 'sine', 2400); this.tone(1800, 0.35, 0.03, 'triangle'); }
  interact() { this.tone(640, 0.18, 0.08, 'triangle', 1280); }
  secret() {
    [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => this.tone(f, 0.7, 0.1, 'sine'), i * 130));
  }
  success() { [660, 880, 1320].forEach((f, i) => setTimeout(() => this.tone(f, 0.35, 0.08, 'sine'), i * 90)); }

  setEnabled(v: boolean) {
    this.enabled = v;
    if (this.master && this.ctx) {
      this.master.gain.cancelScheduledValues(this.ctx.currentTime);
      this.master.gain.linearRampToValueAtTime(v ? 0.9 : 0, this.ctx.currentTime + 0.4);
    }
  }

  dispose() {
    if (this.musicTimer) window.clearInterval(this.musicTimer);
    this.ctx?.close();
    this.ctx = null;
    this.started = false;
  }
}
