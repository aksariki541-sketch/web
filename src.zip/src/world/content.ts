/* =========================================================================
   CONTENT — all copy shown inside the 3D world & UI panels
   ========================================================================= */

export type Project = {
  id: string;
  name: string;
  year: string;
  desc: string;
  long: string;
  tech: string[];
  link: string;
  shape: 'knot' | 'ico' | 'octa' | 'torus' | 'cube';
};

export const ABOUT_PANELS = [
  {
    id: 'identity',
    title: 'IDENTITY',
    subtitle: 'WHO AM I',
    body: 'Arkan Nova — creative engineer & immersive experience designer. I build digital worlds where interface, motion and narrative dissolve into a single object.',
  },
  {
    id: 'biography',
    title: 'BIOGRAPHY',
    subtitle: 'THE PATH',
    body: 'Nine years crafting interfaces for luxury brands, cultural institutions and technology studios. From static pixels to real-time rendered environments.',
  },
  {
    id: 'mission',
    title: 'MISSION',
    subtitle: 'THE PURPOSE',
    body: 'To dissolve the boundary between a website and a place. Every product should feel inhabited — a space you enter, not a page you scroll.',
  },
  {
    id: 'vision',
    title: 'VISION',
    subtitle: 'THE HORIZON',
    body: 'A web made of worlds. Spatial, cinematic, responsive to presence — where a portfolio is an architecture and a brand is a landscape.',
  },
  {
    id: 'philosophy',
    title: 'PHILOSOPHY',
    subtitle: 'THE RULE',
    body: 'Black for silence. Gold for intent. White for truth. Restraint is the highest form of luxury; motion is the highest form of attention.',
  },
];

export const PROJECTS: Project[] = [
  {
    id: 'aurum',
    name: 'AURUM ATELIER',
    year: '2025',
    desc: 'Real-time 3D configurator for a haute joaillerie house.',
    long: 'A WebGL configurator rendering 18k gold, brushed titanium and lab diamonds at 60fps. Physically based materials, IBL captured in-studio, and a bespoke geometry pipeline compressing 40M triangles into 4MB.',
    tech: ['Three.js', 'WebGPU', 'React', 'Draco'],
    link: 'https://example.com/aurum',
    shape: 'knot',
  },
  {
    id: 'nocturne',
    name: 'NOCTURNE OS',
    year: '2024',
    desc: 'Spatial operating system concept for ambient computing.',
    long: 'A gesture-first spatial shell: windows become volumes, notifications become light. Built as a simulated OS running fully in the browser with a custom compositor and 3D window manager.',
    tech: ['TypeScript', 'WebXR', 'GLSL', 'Rust/WASM'],
    link: 'https://example.com/nocturne',
    shape: 'octa',
  },
  {
    id: 'obsidian',
    name: 'OBSIDIAN GALLERY',
    year: '2024',
    desc: 'Virtual museum for a private contemporary art collection.',
    long: 'Twelve rooms, 240 artworks, streaming LOD architecture and a real-time global illumination bake. Visitors walk the space together with spatial voice presence.',
    tech: ['Three.js', 'Colyseus', 'Node.js', 'S3'],
    link: 'https://example.com/obsidian',
    shape: 'cube',
  },
  {
    id: 'helios',
    name: 'HELIOS ENGINE',
    year: '2023',
    desc: 'Rendering engine for cinematic product launches.',
    long: 'A deferred renderer with volumetric gold light shafts, temporal AA and an authoring timeline. Powers launch films rendered live in the browser instead of pre-baked video.',
    tech: ['WebGL2', 'GLSL', 'Vite', 'Zustand'],
    link: 'https://example.com/helios',
    shape: 'ico',
  },
  {
    id: 'meridian',
    name: 'MERIDIAN DATA',
    year: '2023',
    desc: 'Immersive analytics deck for a sovereign fund.',
    long: 'Portfolio risk visualised as an orbital system. 1.2M data points streamed through instanced meshes, with a natural-language query layer for spoken exploration.',
    tech: ['D3', 'Three.js', 'Python', 'DuckDB'],
    link: 'https://example.com/meridian',
    shape: 'torus',
  },
];

export const SKILLS = [
  { id: 'html', name: 'HTML', level: 98, note: 'Semantic architecture & accessibility-first markup.' },
  { id: 'css', name: 'CSS', level: 96, note: 'Design systems, motion, container queries, shaders in CSS.' },
  { id: 'js', name: 'JAVASCRIPT', level: 97, note: 'Nine years of runtime craft, from DOM to WebGL loops.' },
  { id: 'three', name: 'THREE.JS', level: 94, note: 'Scene architecture, shaders, performance budgeting.' },
  { id: 'react', name: 'REACT', level: 95, note: 'Component systems, concurrent rendering, r3f pipelines.' },
  { id: 'node', name: 'NODE.JS', level: 88, note: 'Realtime services, streaming APIs, edge runtimes.' },
  { id: 'python', name: 'PYTHON', level: 82, note: 'Asset pipelines, generative tooling, ML inference.' },
  { id: 'db', name: 'DATABASE', level: 85, note: 'Postgres, vector stores, spatial indexing.' },
  { id: 'uiux', name: 'UI / UX', level: 93, note: 'Cinematic interface design and interaction choreography.' },
];

export const EXPERIENCE = [
  {
    year: '2026',
    role: 'FOUNDER — AURUM STUDIO',
    place: 'Independent',
    text: 'Founded an immersive studio building real-time worlds for luxury maisons and cultural institutions.',
  },
  {
    year: '2024',
    role: 'LEAD CREATIVE ENGINEER',
    place: 'Nocturne Labs',
    text: 'Directed a team of nine engineers shipping spatial interfaces used by 4M monthly visitors.',
  },
  {
    year: '2022',
    role: 'SENIOR WEBGL DEVELOPER',
    place: 'Helios Interactive',
    text: 'Built the rendering core behind six award-winning product launches — FWA, Awwwards SOTD ×4.',
  },
  {
    year: '2020',
    role: 'FRONTEND ARCHITECT',
    place: 'Meridian Group',
    text: 'Rebuilt a global financial platform, cutting time-to-interactive by 71% across 22 markets.',
  },
  {
    year: '2017',
    role: 'INTERACTIVE DEVELOPER',
    place: 'Studio Obsidian',
    text: 'First steps: microsites, motion systems, and an obsession with frames that never drop.',
  },
];

export const CONTACTS = [
  { id: 'email', label: 'EMAIL', value: 'hello@aurum.world', href: 'mailto:hello@aurum.world' },
  { id: 'x', label: 'X / TWITTER', value: '@aurum_world', href: 'https://x.com' },
  { id: 'github', label: 'GITHUB', value: 'github.com/aurum', href: 'https://github.com' },
  { id: 'linkedin', label: 'LINKEDIN', value: 'in/aurum-studio', href: 'https://linkedin.com' },
];

export const NPC_DIALOG = [
  'SYSTEM UNIT V-01 ONLINE. Welcome to the AURUM nexus, traveller.',
  'Use W A S D or the joystick to move. SHIFT to run, SPACE to leap.',
  'Approach any gold portal and press E to enter its chamber.',
  'They say a seventh sector exists… hidden behind the north pillars. Find the anomaly.',
  'Enjoy the architecture. It was rendered entirely for you.',
];

export const SECRET_TEXT = {
  title: 'SECTOR VII — CLASSIFIED',
  body: 'You found the anomaly. This chamber does not appear on any map of the nexus. Inside the monolith is the only line of code that matters: build things people can walk inside.',
};
