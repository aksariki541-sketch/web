/* =========================================================================
   ENVIRONMENT / ROOM SYSTEM
   ========================================================================= */
import * as THREE from 'three';
import { CONFIG, ROOMS, RoomId, roomById, type Quality } from './config';
import { ABOUT_PANELS, CONTACTS, EXPERIENCE, PROJECTS, SKILLS } from './content';
import {
  blackGlass,
  cardTexture,
  darkMatte,
  floorTexture,
  glowMaterial,
  glowTexture,
  goldMaterial,
  makeLabel,
  panelTexture,
  portalTexture,
  track,
} from './gfx';

export type InteractKind =
  | 'portal'
  | 'panel'
  | 'project'
  | 'skill'
  | 'milestone'
  | 'terminal'
  | 'npc'
  | 'secret'
  | 'anomaly';

export type Interactable = {
  id: string;
  room: RoomId;
  kind: InteractKind;
  object: THREE.Object3D;
  position: THREE.Vector3;
  title: string;
  prompt: string;
  payload?: unknown;
  target?: RoomId;
  hidden?: boolean;
  update?: (dt: number, t: number, near: number) => void;
};

export type BuildCtx = {
  root: THREE.Group;
  register: (i: Interactable) => void;
  quality: Quality;
};

const v3 = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);

/* ---------- SHARED PIECES ---------- */

export const buildFloorDisc = (
  ctx: BuildCtx,
  cx: number,
  cz: number,
  radius: number,
  rings = 6
) => {
  const g = new THREE.Group();
  const floor = new THREE.Mesh(
    track(new THREE.CircleGeometry(radius, 72)),
    track(
      new THREE.MeshStandardMaterial({
        map: floorTexture(rings),
        color: 0x1a1a1a,
        metalness: 0.92,
        roughness: 0.12,
      })
    )
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  g.add(floor);

  // gold rim
  const rim = new THREE.Mesh(track(new THREE.TorusGeometry(radius, 0.12, 8, 96)), goldMaterial({ emissiveIntensity: 0.8 }));
  rim.rotation.x = Math.PI / 2;
  rim.position.y = 0.06;
  g.add(rim);

  const rimGlow = new THREE.Mesh(track(new THREE.TorusGeometry(radius, 0.3, 6, 96)), glowMaterial(CONFIG.goldLight, 0.18));
  rimGlow.rotation.x = Math.PI / 2;
  rimGlow.position.y = 0.06;
  g.add(rimGlow);

  // underside skirt so the disc reads as a floating platform
  const skirt = new THREE.Mesh(
    track(new THREE.CylinderGeometry(radius, radius * 0.82, 2.6, 64, 1, true)),
    track(new THREE.MeshStandardMaterial({ color: 0x080808, metalness: 0.9, roughness: 0.4, side: THREE.BackSide }))
  );
  skirt.position.y = -1.3;
  g.add(skirt);

  g.position.set(cx, 0, cz);
  ctx.root.add(g);
  return g;
};

export const buildPillars = (
  ctx: BuildCtx,
  cx: number,
  cz: number,
  radius: number,
  count: number,
  height: number,
  skipAngles: number[] = []
) => {
  const g = new THREE.Group();
  const shaft = track(new THREE.CylinderGeometry(0.42, 0.52, height, 12));
  const capGeo = track(new THREE.CylinderGeometry(0.62, 0.42, 0.35, 12));
  const stripGeo = track(new THREE.BoxGeometry(0.1, height * 0.82, 0.1));
  const mat = darkMatte(0x0c0c0c, 0.42);
  const gold = goldMaterial({ emissiveIntensity: 0.5 });
  const strip = glowMaterial(CONFIG.goldLight, 0.85);

  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2;
    if (skipAngles.some((sa) => Math.abs(Math.atan2(Math.sin(a - sa), Math.cos(a - sa))) < 0.36)) continue;
    const x = Math.cos(a) * radius;
    const z = Math.sin(a) * radius;
    const p = new THREE.Mesh(shaft, mat);
    p.position.set(x, height / 2, z);
    p.castShadow = true;
    g.add(p);
    const cap = new THREE.Mesh(capGeo, gold);
    cap.position.set(x, height, z);
    g.add(cap);
    const base = new THREE.Mesh(capGeo, gold);
    base.position.set(x, 0.16, z);
    base.rotation.x = Math.PI;
    g.add(base);
    const s = new THREE.Mesh(stripGeo, strip);
    s.position.set(x + Math.cos(a) * -0.44, height / 2, z + Math.sin(a) * -0.44);
    g.add(s);
  }
  g.position.set(cx, 0, cz);
  ctx.root.add(g);
  return g;
};

export const buildWalkway = (ctx: BuildCtx, from: THREE.Vector2, to: THREE.Vector2, width: number) => {
  const dir = to.clone().sub(from);
  const len = dir.length();
  const angle = Math.atan2(dir.y, dir.x);
  const mid = from.clone().add(dir.clone().multiplyScalar(0.5));
  const g = new THREE.Group();

  const deck = new THREE.Mesh(
    track(new THREE.PlaneGeometry(len, width)),
    track(new THREE.MeshStandardMaterial({ color: 0x0b0b0b, metalness: 0.9, roughness: 0.16 }))
  );
  deck.rotation.x = -Math.PI / 2;
  deck.receiveShadow = true;
  g.add(deck);

  // gold rails + light strips
  for (const side of [-1, 1]) {
    const rail = new THREE.Mesh(track(new THREE.BoxGeometry(len, 0.1, 0.14)), goldMaterial({ emissiveIntensity: 0.7 }));
    rail.position.set(0, 0.07, (side * width) / 2 - side * 0.16);
    g.add(rail);
    const strip = new THREE.Mesh(track(new THREE.BoxGeometry(len, 0.02, 0.3)), glowMaterial(CONFIG.goldLight, 0.5));
    strip.position.set(0, 0.03, (side * width) / 2 - side * 0.55);
    g.add(strip);
  }
  // rhythm arches over the walkway
  const arches = Math.max(2, Math.floor(len / 9));
  for (let i = 1; i < arches; i++) {
    const t = i / arches;
    const arch = new THREE.Mesh(
      track(new THREE.TorusGeometry(width * 0.62, 0.06, 6, 24, Math.PI)),
      goldMaterial({ emissiveIntensity: 0.55 })
    );
    arch.position.set(-len / 2 + len * t, 0, 0);
    arch.rotation.y = Math.PI / 2;
    g.add(arch);
  }

  g.position.set(mid.x, 0.01, mid.y);
  g.rotation.y = -angle;
  ctx.root.add(g);
  return g;
};

/* ---------- PORTAL ---------- */
export const buildPortal = (
  ctx: BuildCtx,
  opts: {
    id: string;
    room: RoomId;
    target: RoomId;
    position: THREE.Vector3;
    rotationY: number;
    title: string;
    subtitle: string;
    hidden?: boolean;
  }
) => {
  const g = new THREE.Group();
  g.position.copy(opts.position);
  g.rotation.y = opts.rotationY;

  const goldM = goldMaterial({ emissiveIntensity: 0.35 });
  // arch frame
  const frame = new THREE.Mesh(track(new THREE.TorusGeometry(2.5, 0.13, 10, 60)), goldM);
  frame.position.y = 2.9;
  frame.castShadow = true;
  g.add(frame);
  const frame2 = new THREE.Mesh(track(new THREE.TorusGeometry(2.85, 0.05, 8, 60)), goldM);
  frame2.position.y = 2.9;
  g.add(frame2);

  // energy surface
  const surfMat = track(
    new THREE.MeshBasicMaterial({
      map: portalTexture(),
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
      toneMapped: false,
    })
  );
  const surface = new THREE.Mesh(track(new THREE.CircleGeometry(2.42, 48)), surfMat);
  surface.position.y = 2.9;
  g.add(surface);

  // base plinth
  const plinth = new THREE.Mesh(track(new THREE.BoxGeometry(6.2, 0.28, 1.5)), blackGlass(0.15));
  plinth.position.y = 0.14;
  g.add(plinth);
  const plinthGold = new THREE.Mesh(track(new THREE.BoxGeometry(6.3, 0.05, 0.24)), glowMaterial(CONFIG.goldLight, 0.9));
  plinthGold.position.set(0, 0.3, 0.66);
  g.add(plinthGold);

  // side monoliths
  for (const s of [-1, 1]) {
    const m = new THREE.Mesh(track(new THREE.BoxGeometry(0.42, 5.4, 0.42)), darkMatte(0x0d0d0d, 0.35));
    m.position.set(s * 3.05, 2.7, 0);
    m.castShadow = true;
    g.add(m);
    const cap = new THREE.Mesh(track(new THREE.OctahedronGeometry(0.3)), goldM);
    cap.position.set(s * 3.05, 5.6, 0);
    g.add(cap);
  }

  // label
  const label = makeLabel(opts.title, { sub: opts.subtitle, size: 82, scale: 7 });
  label.position.set(0, 6.5, 0);
  g.add(label);

  const light = new THREE.PointLight(CONFIG.goldColor, 5, 20, 2);
  light.position.set(0, 3, 0.8);
  g.add(light);

  const glow = new THREE.Sprite(
    track(
      new THREE.SpriteMaterial({
        map: glowTexture(),
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        opacity: 0.35,
        toneMapped: false,
      })
    )
  );
  glow.scale.set(9, 9, 1);
  glow.position.y = 2.9;
  g.add(glow);

  if (opts.hidden) g.visible = false;
  ctx.root.add(g);

  let open = 0;
  const inter: Interactable = {
    id: opts.id,
    room: opts.room,
    kind: 'portal',
    object: g,
    position: opts.position.clone(),
    title: opts.title,
    prompt: 'ENTER',
    target: opts.target,
    hidden: opts.hidden,
    update: (dt, t, near) => {
      open += (near - open) * Math.min(1, dt * 4);
      surface.rotation.z += dt * (0.15 + open * 0.5);
      surfMat.opacity = 0.32 + open * 0.55 + Math.sin(t * 2.4) * 0.05;
      surface.scale.setScalar(0.92 + open * 0.1 + Math.sin(t * 1.7) * 0.015);
      frame.rotation.z = Math.sin(t * 0.6) * 0.05;
      light.intensity = 4 + open * 16 + Math.sin(t * 3) * 0.8;
      glow.material.opacity = 0.28 + open * 0.5;
      glow.scale.setScalar(9 + open * 3.5 + Math.sin(t * 2) * 0.3);
      label.position.y = 6.5 + Math.sin(t * 1.2 + opts.position.x) * 0.14;
      (label.material as THREE.SpriteMaterial).opacity = 0.55 + open * 0.45;
    },
  };
  ctx.register(inter);
  return { group: g, interactable: inter };
};

/* ---------- HOLOGRAM PANEL (About / generic info) ---------- */
const buildHoloPanel = (
  ctx: BuildCtx,
  opts: {
    id: string;
    room: RoomId;
    kind: InteractKind;
    position: THREE.Vector3;
    rotationY: number;
    title: string;
    subtitle: string;
    body: string;
    payload?: unknown;
    width?: number;
  }
) => {
  const g = new THREE.Group();
  g.position.copy(opts.position);
  g.rotation.y = opts.rotationY;

  const W = opts.width ?? 4.6;
  const H = W * 0.625;

  const tex = panelTexture(opts.title, opts.subtitle, opts.body);
  const mat = track(
    new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.15, side: THREE.DoubleSide, toneMapped: false })
  );
  const screen = new THREE.Mesh(track(new THREE.PlaneGeometry(W, H)), mat);
  screen.position.y = 2.9;
  g.add(screen);

  const frame = new THREE.Mesh(
    track(new THREE.TorusGeometry(W * 0.5, 0.035, 6, 4)),
    goldMaterial({ emissiveIntensity: 0.7 })
  );
  frame.rotation.z = Math.PI / 4;
  frame.scale.set(1, (H / W) * 1.0, 1);
  frame.position.y = 2.9;
  g.add(frame);

  // pedestal + emitter
  const ped = new THREE.Mesh(track(new THREE.CylinderGeometry(0.7, 0.95, 0.9, 20)), blackGlass(0.12));
  ped.position.y = 0.45;
  ped.castShadow = true;
  g.add(ped);
  const emitter = new THREE.Mesh(track(new THREE.CylinderGeometry(0.55, 0.55, 0.08, 20)), glowMaterial(CONFIG.goldLight, 0.9));
  emitter.position.y = 0.95;
  g.add(emitter);
  const beam = new THREE.Mesh(
    track(new THREE.ConeGeometry(W * 0.42, 2.1, 24, 1, true)),
    glowMaterial(CONFIG.goldColor, 0.06)
  );
  beam.position.y = 2.0;
  g.add(beam);

  const light = new THREE.PointLight(CONFIG.goldLight, 2, 12, 2);
  light.position.set(0, 1.6, 0.4);
  g.add(light);

  const ring = new THREE.Mesh(track(new THREE.TorusGeometry(1.15, 0.02, 6, 40)), glowMaterial(CONFIG.goldLight, 0.5));
  ring.rotation.x = Math.PI / 2;
  ring.position.y = 1.0;
  g.add(ring);

  ctx.root.add(g);

  let a = 0;
  ctx.register({
    id: opts.id,
    room: opts.room,
    kind: opts.kind,
    object: g,
    position: opts.position.clone(),
    title: opts.title,
    prompt: 'READ',
    payload: opts.payload,
    update: (dt, t, near) => {
      a += (near - a) * Math.min(1, dt * 3.2);
      mat.opacity = 0.1 + a * 0.9;
      screen.position.y = 2.9 + Math.sin(t * 1.1 + opts.position.x * 0.4) * 0.09;
      screen.scale.setScalar(0.9 + a * 0.12);
      frame.position.y = screen.position.y;
      frame.scale.set(0.9 + a * 0.12, ((H / W) * (0.9 + a * 0.12)) as number, 1);
      (beam.material as THREE.MeshBasicMaterial).opacity = 0.03 + a * 0.1;
      light.intensity = 1.4 + a * 7;
      ring.rotation.z += dt * (0.2 + a);
      ring.scale.setScalar(1 + a * 0.15 + Math.sin(t * 2) * 0.02);
    },
  });
  return g;
};

/* ---------- ROOM 01 — MAIN HUB ---------- */
export const buildHub = (ctx: BuildCtx) => {
  const hub = roomById('hub');
  buildFloorDisc(ctx, 0, 0, hub.radius, 7);
  buildPillars(
    ctx,
    0,
    0,
    hub.radius - 1.6,
    16,
    9,
    ROOMS.filter((r) => r.id !== 'hub').map((r) => -(r.angle * Math.PI) / 180)
  );

  // central emblem platform
  const center = new THREE.Group();
  const dais = new THREE.Mesh(track(new THREE.CylinderGeometry(4.2, 4.8, 0.4, 48)), blackGlass(0.08));
  dais.position.y = 0.2;
  dais.receiveShadow = true;
  center.add(dais);
  const daisRim = new THREE.Mesh(track(new THREE.TorusGeometry(4.2, 0.06, 8, 64)), glowMaterial(CONFIG.goldLight, 0.8));
  daisRim.rotation.x = Math.PI / 2;
  daisRim.position.y = 0.42;
  center.add(daisRim);

  // floating rings
  const rings: THREE.Mesh[] = [];
  for (let i = 0; i < 3; i++) {
    const r = new THREE.Mesh(
      track(new THREE.TorusGeometry(2.4 + i * 0.85, 0.045 + i * 0.012, 8, 80)),
      goldMaterial({ emissive: CONFIG.goldLight, emissiveIntensity: 0.9 })
    );
    r.position.y = 7 + i * 0.7;
    r.rotation.x = Math.PI / 2 + (i - 1) * 0.35;
    center.add(r);
    rings.push(r);
  }
  const core = new THREE.Mesh(track(new THREE.IcosahedronGeometry(1.1, 1)), glowMaterial(CONFIG.goldLight, 0.9));
  core.position.y = 8;
  center.add(core);
  const coreCage = new THREE.Mesh(
    track(new THREE.IcosahedronGeometry(1.5, 1)),
    track(new THREE.MeshBasicMaterial({ color: CONFIG.goldColor, wireframe: true, transparent: true, opacity: 0.5, toneMapped: false }))
  );
  coreCage.position.y = 8;
  center.add(coreCage);
  const coreLight = new THREE.PointLight(CONFIG.goldLight, 25, 40, 2);
  coreLight.position.y = 8;
  center.add(coreLight);

  const brand = makeLabel(CONFIG.brand, { sub: CONFIG.brandSub, size: 100, scale: 11 });
  brand.position.set(0, 12.4, 0);
  center.add(brand);
  ctx.root.add(center);

  ctx.register({
    id: 'hub-core',
    room: 'hub',
    kind: 'terminal',
    object: core,
    position: v3(0, 0, 0),
    title: 'NEXUS CORE',
    prompt: 'SCAN',
    update: (dt, t, near) => {
      rings.forEach((r, i) => {
        r.rotation.z += dt * (0.25 + i * 0.16) * (1 + near);
        r.rotation.y += dt * 0.08 * (i % 2 ? 1 : -1);
        r.position.y = 7 + i * 0.7 + Math.sin(t * 0.8 + i) * 0.22;
      });
      core.rotation.y += dt * 0.4;
      core.rotation.x += dt * 0.17;
      core.scale.setScalar(1 + Math.sin(t * 1.8) * 0.06 + near * 0.12);
      coreCage.rotation.y -= dt * 0.22;
      coreLight.intensity = 20 + Math.sin(t * 1.4) * 6 + near * 14;
      brand.position.y = 12.4 + Math.sin(t * 0.7) * 0.18;
    },
  });

  // portals to each room
  ROOMS.filter((r) => r.id !== 'hub').forEach((room) => {
    const a = (room.angle * Math.PI) / 180;
    const dist = hub.radius - 3.4;
    const pos = v3(Math.cos(a) * dist, 0, -Math.sin(a) * dist);
    buildPortal(ctx, {
      id: `portal-${room.id}`,
      room: 'hub',
      target: room.id,
      position: pos,
      rotationY: Math.atan2(pos.x, pos.z) + Math.PI,
      title: room.name,
      subtitle: room.tag,
      hidden: room.hidden,
    });
  });

  /* hidden anomaly — unlocks the secret sector */
  const anomalyPos = v3(Math.cos(Math.PI * 0.72) * (hub.radius - 6), 0, -Math.sin(Math.PI * 0.72) * (hub.radius - 6));
  const anomaly = new THREE.Group();
  anomaly.position.copy(anomalyPos);
  const shard = new THREE.Mesh(
    track(new THREE.OctahedronGeometry(0.55, 0)),
    track(
      new THREE.MeshStandardMaterial({
        color: 0x0a0a0a,
        metalness: 1,
        roughness: 0.05,
        emissive: new THREE.Color(CONFIG.goldDeep),
        emissiveIntensity: 0.3,
      })
    )
  );
  shard.position.y = 1.3;
  anomaly.add(shard);
  const shardGlow = new THREE.Mesh(track(new THREE.OctahedronGeometry(0.85, 0)), glowMaterial(CONFIG.goldLight, 0.12));
  shardGlow.position.y = 1.3;
  anomaly.add(shardGlow);
  const shardLight = new THREE.PointLight(CONFIG.goldLight, 1.5, 8, 2);
  shardLight.position.y = 1.3;
  anomaly.add(shardLight);
  ctx.root.add(anomaly);

  ctx.register({
    id: 'anomaly',
    room: 'hub',
    kind: 'anomaly',
    object: anomaly,
    position: anomalyPos.clone(),
    title: 'UNKNOWN ANOMALY',
    prompt: 'ANALYSE',
    update: (dt, t, near) => {
      shard.rotation.y += dt * 0.8;
      shard.rotation.x += dt * 0.35;
      shard.position.y = 1.3 + Math.sin(t * 1.5) * 0.16;
      shardGlow.position.y = shard.position.y;
      shardGlow.rotation.copy(shard.rotation);
      (shardGlow.material as THREE.MeshBasicMaterial).opacity = 0.08 + near * 0.4 + Math.sin(t * 4) * 0.03;
      shardLight.intensity = 1.2 + near * 10;
    },
  });

  // walkways to every room
  ROOMS.filter((r) => r.id !== 'hub').forEach((room) => {
    const a = (room.angle * Math.PI) / 180;
    const from = new THREE.Vector2(Math.cos(a) * (hub.radius - 0.6), -Math.sin(a) * (hub.radius - 0.6));
    const to = new THREE.Vector2(room.center[0], -room.center[1]);
    const dir = to.clone().sub(from).normalize();
    const end = to.clone().sub(dir.multiplyScalar(room.radius - 1));
    const wg = buildWalkway(ctx, from, end, CONFIG.walkwayWidth);
    if (room.hidden) wg.visible = false;
    if (room.hidden) wg.name = 'secret-walkway';
  });
};

/* ---------- ROOM 02 — ABOUT ---------- */
export const buildAbout = (ctx: BuildCtx) => {
  const room = roomById('about');
  const [cx, cz] = [room.center[0], -room.center[1]];
  buildFloorDisc(ctx, cx, cz, room.radius, 5);
  buildPillars(ctx, cx, cz, room.radius - 1.4, 14, 8, [Math.atan2(-cz, -cx)]);

  const title = makeLabel('ABOUT', { sub: 'DIGITAL MUSEUM OF SELF', size: 92, scale: 10 });
  title.position.set(cx, 9.5, cz);
  ctx.root.add(title);

  ABOUT_PANELS.forEach((p, i) => {
    const spread = Math.PI * 1.25;
    const a = -spread / 2 + (i / (ABOUT_PANELS.length - 1)) * spread + Math.atan2(-cz, -cx) + Math.PI;
    const r = room.radius - 5.5;
    const pos = v3(cx + Math.cos(a) * r, 0, cz + Math.sin(a) * r);
    buildHoloPanel(ctx, {
      id: `about-${p.id}`,
      room: 'about',
      kind: 'panel',
      position: pos,
      rotationY: Math.atan2(cx - pos.x, cz - pos.z),
      title: p.title,
      subtitle: p.subtitle,
      body: p.body,
      payload: p,
    });
  });

  // central statue: rotating faceted bust abstraction
  const g = new THREE.Group();
  g.position.set(cx, 0, cz);
  const base = new THREE.Mesh(track(new THREE.CylinderGeometry(1.8, 2.2, 1, 8)), blackGlass(0.1));
  base.position.y = 0.5;
  g.add(base);
  const statue = new THREE.Mesh(
    track(new THREE.DodecahedronGeometry(1.5, 0)),
    goldMaterial({ rough: 0.12, emissiveIntensity: 0.22 })
  );
  statue.position.y = 3.1;
  statue.castShadow = true;
  g.add(statue);
  const halo = new THREE.Mesh(track(new THREE.TorusGeometry(2.3, 0.03, 6, 60)), glowMaterial(CONFIG.goldLight, 0.7));
  halo.position.y = 3.1;
  halo.rotation.x = Math.PI / 2.6;
  g.add(halo);
  const spot = new THREE.SpotLight(CONFIG.goldLight, 40, 22, 0.6, 0.6, 2);
  spot.position.set(cx, 12, cz);
  spot.target.position.set(cx, 0, cz);
  ctx.root.add(spot, spot.target);
  ctx.root.add(g);

  ctx.register({
    id: 'about-statue',
    room: 'about',
    kind: 'terminal',
    object: statue,
    position: v3(cx, 0, cz),
    title: CONFIG.owner,
    prompt: 'INSPECT',
    update: (dt, t, near) => {
      statue.rotation.y += dt * 0.25;
      statue.position.y = 3.1 + Math.sin(t * 0.9) * 0.16;
      halo.position.y = statue.position.y;
      halo.rotation.z += dt * 0.4;
      halo.scale.setScalar(1 + near * 0.1);
      title.position.y = 9.5 + Math.sin(t * 0.6) * 0.15;
    },
  });
};

/* ---------- ROOM 03 — PROJECTS ---------- */
const shapeGeo = (s: string): THREE.BufferGeometry => {
  switch (s) {
    case 'knot':
      return new THREE.TorusKnotGeometry(0.5, 0.16, 96, 16);
    case 'ico':
      return new THREE.IcosahedronGeometry(0.72, 0);
    case 'octa':
      return new THREE.OctahedronGeometry(0.78, 0);
    case 'torus':
      return new THREE.TorusGeometry(0.55, 0.2, 16, 40);
    default:
      return new THREE.BoxGeometry(1, 1, 1);
  }
};

export const buildProjects = (ctx: BuildCtx) => {
  const room = roomById('projects');
  const [cx, cz] = [room.center[0], -room.center[1]];
  buildFloorDisc(ctx, cx, cz, room.radius, 4);
  buildPillars(ctx, cx, cz, room.radius - 1.4, 12, 8.5, [Math.atan2(-cz, -cx)]);

  const title = makeLabel('PROJECTS', { sub: 'SELECTED WORKS 2023 — 2026', size: 92, scale: 11 });
  title.position.set(cx, 9.8, cz);
  ctx.root.add(title);

  PROJECTS.forEach((p, i) => {
    const spread = Math.PI * 1.45;
    const a = -spread / 2 + (i / (PROJECTS.length - 1)) * spread + Math.atan2(-cz, -cx) + Math.PI;
    const r = room.radius - 5.8;
    const pos = v3(cx + Math.cos(a) * r, 0, cz + Math.sin(a) * r);

    const g = new THREE.Group();
    g.position.copy(pos);
    g.rotation.y = Math.atan2(cx - pos.x, cz - pos.z);

    // pedestal
    const ped = new THREE.Mesh(track(new THREE.CylinderGeometry(1.1, 1.4, 1.1, 6)), blackGlass(0.1));
    ped.position.y = 0.55;
    ped.castShadow = true;
    g.add(ped);
    const pedRim = new THREE.Mesh(track(new THREE.TorusGeometry(1.12, 0.035, 6, 6)), glowMaterial(CONFIG.goldLight, 0.9));
    pedRim.rotation.x = Math.PI / 2;
    pedRim.position.y = 1.1;
    g.add(pedRim);

    // floating card
    const cardMat = track(
      new THREE.MeshBasicMaterial({
        map: cardTexture(p.name, p.year, p.desc, p.tech),
        transparent: true,
        opacity: 0.5,
        side: THREE.DoubleSide,
        toneMapped: false,
      })
    );
    const card = new THREE.Mesh(track(new THREE.PlaneGeometry(2.4, 3.2)), cardMat);
    card.position.set(0, 3.5, -0.1);
    g.add(card);
    const cardFrame = new THREE.Mesh(
      track(new THREE.BoxGeometry(2.56, 3.36, 0.04)),
      track(
        new THREE.MeshStandardMaterial({
          color: CONFIG.goldColor,
          metalness: 1,
          roughness: 0.2,
          transparent: true,
          opacity: 0.55,
          emissive: new THREE.Color(CONFIG.goldDeep),
          emissiveIntensity: 0.3,
        })
      )
    );
    cardFrame.position.set(0, 3.5, -0.16);
    g.add(cardFrame);

    // miniature 3D object above the pedestal
    const mini = new THREE.Mesh(track(shapeGeo(p.shape)), goldMaterial({ rough: 0.14, emissiveIntensity: 0.35 }));
    mini.position.set(0, 1.9, 0.9);
    mini.scale.setScalar(0.75);
    mini.castShadow = true;
    g.add(mini);

    const light = new THREE.PointLight(CONFIG.goldColor, 3, 14, 2);
    light.position.set(0, 2.6, 1.2);
    g.add(light);

    const halo = new THREE.Sprite(
      track(
        new THREE.SpriteMaterial({
          map: glowTexture(),
          transparent: true,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
          opacity: 0.2,
          toneMapped: false,
        })
      )
    );
    halo.scale.set(6, 6, 1);
    halo.position.set(0, 3, 0);
    g.add(halo);

    ctx.root.add(g);

    let a2 = 0;
    ctx.register({
      id: `project-${p.id}`,
      room: 'projects',
      kind: 'project',
      object: g,
      position: pos.clone(),
      title: p.name,
      prompt: 'OPEN DOSSIER',
      payload: p,
      update: (dt, t, near) => {
        a2 += (near - a2) * Math.min(1, dt * 3.4);
        mini.rotation.y += dt * (0.5 + a2 * 1.6);
        mini.rotation.x += dt * 0.22;
        mini.position.y = 1.9 + Math.sin(t * 1.3 + i) * 0.14;
        card.position.y = 3.5 + Math.sin(t * 0.9 + i * 0.7) * 0.12;
        cardFrame.position.y = card.position.y;
        card.scale.setScalar(0.94 + a2 * 0.14);
        cardFrame.scale.setScalar(0.94 + a2 * 0.14);
        cardMat.opacity = 0.4 + a2 * 0.6;
        (cardFrame.material as THREE.MeshStandardMaterial).opacity = 0.4 + a2 * 0.6;
        (cardFrame.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.2 + a2 * 1.1;
        light.intensity = 2 + a2 * 12;
        halo.material.opacity = 0.14 + a2 * 0.3;
        pedRim.rotation.z += dt * (0.3 + a2);
      },
    });
  });
};

/* ---------- ROOM 04 — SKILLS LAB ---------- */
export const buildSkills = (ctx: BuildCtx) => {
  const room = roomById('skills');
  const [cx, cz] = [room.center[0], -room.center[1]];
  buildFloorDisc(ctx, cx, cz, room.radius, 6);
  buildPillars(ctx, cx, cz, room.radius - 1.4, 10, 7.5, [Math.atan2(-cz, -cx)]);

  const title = makeLabel('SKILLS LAB', { sub: 'CAPABILITY MATRIX', size: 92, scale: 11 });
  title.position.set(cx, 10.4, cz);
  ctx.root.add(title);

  // energy core
  const coreG = new THREE.Group();
  coreG.position.set(cx, 0, cz);
  const pod = new THREE.Mesh(track(new THREE.CylinderGeometry(2.4, 3, 0.8, 24)), blackGlass(0.1));
  pod.position.y = 0.4;
  coreG.add(pod);
  const core = new THREE.Mesh(track(new THREE.IcosahedronGeometry(1.5, 2)), glowMaterial(CONFIG.goldLight, 0.85));
  core.position.y = 4;
  coreG.add(core);
  const shell = new THREE.Mesh(
    track(new THREE.SphereGeometry(2.1, 24, 18)),
    track(new THREE.MeshBasicMaterial({ color: CONFIG.goldColor, wireframe: true, transparent: true, opacity: 0.28, toneMapped: false }))
  );
  shell.position.y = 4;
  coreG.add(shell);
  const coreRings: THREE.Mesh[] = [];
  for (let i = 0; i < 3; i++) {
    const r = new THREE.Mesh(track(new THREE.TorusGeometry(2.7 + i * 0.4, 0.035, 6, 60)), goldMaterial({ emissiveIntensity: 1 }));
    r.position.y = 4;
    r.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
    coreG.add(r);
    coreRings.push(r);
  }
  const coreLight = new THREE.PointLight(CONFIG.goldLight, 22, 34, 2);
  coreLight.position.y = 4;
  coreG.add(coreLight);
  ctx.root.add(coreG);

  ctx.register({
    id: 'skills-core',
    room: 'skills',
    kind: 'terminal',
    object: core,
    position: v3(cx, 0, cz),
    title: 'ENERGY CORE',
    prompt: 'SYNC',
    update: (dt, t, near) => {
      core.rotation.y += dt * 0.5;
      core.rotation.z += dt * 0.2;
      core.scale.setScalar(1 + Math.sin(t * 2.4) * 0.07 + near * 0.15);
      shell.rotation.y -= dt * 0.15;
      coreRings.forEach((r, i) => {
        r.rotation.x += dt * (0.3 + i * 0.14);
        r.rotation.y += dt * (0.22 - i * 0.06);
      });
      coreLight.intensity = 18 + Math.sin(t * 2) * 5 + near * 12;
    },
  });

  // skill nodes orbiting the core
  SKILLS.forEach((s, i) => {
    const a = (i / SKILLS.length) * Math.PI * 2;
    const r = room.radius - 6.5;
    const pos = v3(cx + Math.cos(a) * r, 0, cz + Math.sin(a) * r);
    const g = new THREE.Group();
    g.position.copy(pos);
    g.rotation.y = Math.atan2(cx - pos.x, cz - pos.z);

    const ped = new THREE.Mesh(track(new THREE.CylinderGeometry(0.8, 1, 0.9, 6)), blackGlass(0.12));
    ped.position.y = 0.45;
    ped.castShadow = true;
    g.add(ped);

    const obj = new THREE.Mesh(
      track(
        i % 3 === 0
          ? new THREE.OctahedronGeometry(0.62, 0)
          : i % 3 === 1
            ? new THREE.TorusKnotGeometry(0.38, 0.13, 64, 12)
            : new THREE.IcosahedronGeometry(0.62, 0)
      ),
      goldMaterial({ rough: 0.15, emissiveIntensity: 0.3 })
    );
    obj.position.y = 2.3;
    obj.castShadow = true;
    g.add(obj);

    const ring1 = new THREE.Mesh(track(new THREE.TorusGeometry(1.05, 0.02, 6, 44)), glowMaterial(CONFIG.goldLight, 0.55));
    ring1.position.y = 2.3;
    ring1.rotation.x = Math.PI / 2;
    g.add(ring1);
    const ring2 = new THREE.Mesh(track(new THREE.TorusGeometry(1.25, 0.014, 6, 44)), glowMaterial(CONFIG.goldSoft, 0.4));
    ring2.position.y = 2.3;
    ring2.rotation.x = Math.PI / 3;
    g.add(ring2);

    const label = makeLabel(s.name, { sub: `${s.level}%`, size: 66, scale: 3.6 });
    label.position.y = 4.1;
    (label.material as THREE.SpriteMaterial).opacity = 0.35;
    g.add(label);

    const light = new THREE.PointLight(CONFIG.goldColor, 2, 10, 2);
    light.position.y = 2.4;
    g.add(light);

    // vertical progress bar of the skill level
    const barBg = new THREE.Mesh(track(new THREE.BoxGeometry(0.08, 1.6, 0.08)), darkMatte(0x1a1a1a, 0.6));
    barBg.position.set(1.1, 1.6, 0);
    g.add(barBg);
    const bar = new THREE.Mesh(track(new THREE.BoxGeometry(0.1, 1.6 * (s.level / 100), 0.1)), glowMaterial(CONFIG.goldLight, 0.9));
    bar.position.set(1.1, 0.8 + (1.6 * (s.level / 100)) / 2, 0);
    g.add(bar);

    ctx.root.add(g);

    let a2 = 0;
    ctx.register({
      id: `skill-${s.id}`,
      room: 'skills',
      kind: 'skill',
      object: g,
      position: pos.clone(),
      title: s.name,
      prompt: 'ANALYSE',
      payload: s,
      update: (dt, t, near) => {
        a2 += (near - a2) * Math.min(1, dt * 3.4);
        obj.rotation.y += dt * (0.35 + a2 * 2.2);
        obj.rotation.x += dt * (0.1 + a2 * 0.5);
        obj.position.y = 2.3 + Math.sin(t * 1.2 + i * 0.8) * 0.14;
        ring1.position.y = obj.position.y;
        ring2.position.y = obj.position.y;
        ring1.rotation.z += dt * (0.4 + a2 * 1.5);
        ring2.rotation.y += dt * (0.3 + a2);
        ring1.scale.setScalar(1 + a2 * 0.16);
        light.intensity = 1.2 + a2 * 11;
        (label.material as THREE.SpriteMaterial).opacity = 0.3 + a2 * 0.7;
        label.position.y = 4.1 + Math.sin(t * 1.4 + i) * 0.07;
      },
    });
  });
};

/* ---------- ROOM 05 — EXPERIENCE ---------- */
export const buildExperience = (ctx: BuildCtx) => {
  const room = roomById('experience');
  const [cx, cz] = [room.center[0], -room.center[1]];
  buildFloorDisc(ctx, cx, cz, room.radius, 3);
  buildPillars(ctx, cx, cz, room.radius - 1.4, 12, 7, [Math.atan2(-cz, -cx)]);

  const title = makeLabel('EXPERIENCE', { sub: 'TIMELINE VAULT', size: 92, scale: 11 });
  title.position.set(cx, 9.6, cz);
  ctx.root.add(title);

  // timeline path (gold light ribbon) crossing the room
  const dirIn = new THREE.Vector2(-cx, -cz).normalize();
  const perp = new THREE.Vector2(-dirIn.y, dirIn.x);
  const start = new THREE.Vector2(cx, cz).add(perp.clone().multiplyScalar(-(room.radius - 4)));
  const end = new THREE.Vector2(cx, cz).add(perp.clone().multiplyScalar(room.radius - 4));

  const pathLen = start.distanceTo(end);
  const ribbon = new THREE.Mesh(track(new THREE.PlaneGeometry(pathLen, 1.1)), glowMaterial(CONFIG.goldLight, 0.35));
  ribbon.rotation.x = -Math.PI / 2;
  ribbon.rotation.z = -Math.atan2(end.y - start.y, end.x - start.x);
  ribbon.position.set((start.x + end.x) / 2, 0.05, (start.y + end.y) / 2);
  ctx.root.add(ribbon);

  EXPERIENCE.forEach((e, i) => {
    const t = i / (EXPERIENCE.length - 1);
    const p = start.clone().lerp(end, t);
    const pos = v3(p.x, 0, p.y);
    const g = new THREE.Group();
    g.position.copy(pos);
    g.rotation.y = Math.atan2(cx - pos.x, cz - pos.z) + Math.PI;

    const marker = new THREE.Mesh(track(new THREE.CylinderGeometry(0.9, 1.1, 0.3, 6)), blackGlass(0.1));
    marker.position.y = 0.2;
    g.add(marker);
    const pylon = new THREE.Mesh(track(new THREE.CylinderGeometry(0.09, 0.09, 3.2, 8)), goldMaterial({ emissiveIntensity: 0.8 }));
    pylon.position.y = 1.7;
    g.add(pylon);
    const node = new THREE.Mesh(track(new THREE.OctahedronGeometry(0.4)), glowMaterial(CONFIG.goldLight, 0.9));
    node.position.y = 3.5;
    g.add(node);

    const year = makeLabel(e.year, { size: 92, scale: 3.4 });
    year.position.y = 4.6;
    g.add(year);

    const panelMat = track(
      new THREE.MeshBasicMaterial({
        map: panelTexture(e.role, `${e.year}  ·  ${e.place}`, e.text),
        transparent: true,
        opacity: 0.18,
        side: THREE.DoubleSide,
        toneMapped: false,
      })
    );
    const panel = new THREE.Mesh(track(new THREE.PlaneGeometry(4.4, 2.75)), panelMat);
    panel.position.set(0, 2.9, i % 2 === 0 ? 2.6 : -2.6);
    panel.rotation.y = i % 2 === 0 ? 0 : Math.PI;
    g.add(panel);

    const light = new THREE.PointLight(CONFIG.goldColor, 2.5, 12, 2);
    light.position.y = 3.4;
    g.add(light);

    ctx.root.add(g);

    let a2 = 0;
    ctx.register({
      id: `exp-${i}`,
      room: 'experience',
      kind: 'milestone',
      object: g,
      position: pos.clone(),
      title: `${e.year} — ${e.role}`,
      prompt: 'REVIEW',
      payload: e,
      update: (dt, tt, near) => {
        a2 += (near - a2) * Math.min(1, dt * 3);
        node.rotation.y += dt * (0.6 + a2 * 1.4);
        node.position.y = 3.5 + Math.sin(tt * 1.4 + i) * 0.12;
        node.scale.setScalar(1 + a2 * 0.35 + Math.sin(tt * 3 + i) * 0.04);
        panelMat.opacity = 0.12 + a2 * 0.85;
        panel.position.y = 2.9 + Math.sin(tt * 1.1 + i * 0.6) * 0.1;
        panel.scale.setScalar(0.9 + a2 * 0.14);
        light.intensity = 1.6 + a2 * 10;
        (year.material as THREE.SpriteMaterial).opacity = 0.4 + a2 * 0.6;
      },
    });
  });
};

/* ---------- ROOM 06 — CONTACT ---------- */
export const buildContact = (ctx: BuildCtx) => {
  const room = roomById('contact');
  const [cx, cz] = [room.center[0], -room.center[1]];
  buildFloorDisc(ctx, cx, cz, room.radius, 5);
  buildPillars(ctx, cx, cz, room.radius - 1.4, 12, 8, [Math.atan2(-cz, -cx)]);

  const title = makeLabel('CONTACT', { sub: 'CONTROL CENTER', size: 92, scale: 10 });
  title.position.set(cx, 9.6, cz);
  ctx.root.add(title);

  // big curved terminal facing the entrance
  const inAngle = Math.atan2(-cz, -cx);
  const facing = inAngle + Math.PI;
  const tPos = v3(cx + Math.cos(facing) * (room.radius - 6.5), 0, cz + Math.sin(facing) * (room.radius - 6.5));
  const g = new THREE.Group();
  g.position.copy(tPos);
  g.rotation.y = Math.atan2(cx - tPos.x, cz - tPos.z);

  const console_ = new THREE.Mesh(track(new THREE.CylinderGeometry(4.2, 4.6, 1.2, 32, 1, true, -0.9, 1.8)), blackGlass(0.12));
  console_.position.y = 0.9;
  g.add(console_);
  const deskTop = new THREE.Mesh(track(new THREE.TorusGeometry(4.4, 0.1, 8, 40, 1.8)), goldMaterial({ emissiveIntensity: 0.8 }));
  deskTop.rotation.x = Math.PI / 2;
  deskTop.rotation.z = -0.9;
  deskTop.position.y = 1.5;
  g.add(deskTop);

  const screenMat = track(
    new THREE.MeshBasicMaterial({
      map: panelTexture('TRANSMIT', 'SECURE CHANNEL OPEN', 'Send a signal into the nexus. Every message is received personally — expect an answer within one rotation of the planet.'),
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide,
      toneMapped: false,
    })
  );
  const screen = new THREE.Mesh(track(new THREE.PlaneGeometry(6.4, 4)), screenMat);
  screen.position.set(0, 4.4, -0.6);
  g.add(screen);
  const frame = new THREE.Mesh(track(new THREE.BoxGeometry(6.7, 4.3, 0.06)), goldMaterial({ emissiveIntensity: 0.5 }));
  frame.position.set(0, 4.4, -0.75);
  g.add(frame);

  // gold light beams
  for (const s of [-1, 1]) {
    const beam = new THREE.Mesh(track(new THREE.CylinderGeometry(0.06, 0.06, 9, 8)), glowMaterial(CONFIG.goldLight, 0.7));
    beam.position.set(s * 4.6, 4.5, 0);
    g.add(beam);
  }
  const light = new THREE.PointLight(CONFIG.goldLight, 12, 26, 2);
  light.position.set(0, 4, 2);
  g.add(light);
  ctx.root.add(g);

  ctx.register({
    id: 'contact-terminal',
    room: 'contact',
    kind: 'terminal',
    object: g,
    position: tPos.clone(),
    title: 'TRANSMISSION TERMINAL',
    prompt: 'OPEN CHANNEL',
    payload: { form: true },
    update: (dt: number, t: number, near: number) => {
      void dt;
      screenMat.opacity = 0.3 + near * 0.65;
      screen.position.y = 4.4 + Math.sin(t * 0.8) * 0.06;
      frame.position.y = screen.position.y;
      light.intensity = 8 + near * 16 + Math.sin(t * 2) * 1.4;
      deskTop.rotation.z = -0.9 + Math.sin(t * 0.4) * 0.02;
    },
  });

  // contact pillars
  CONTACTS.forEach((c, i) => {
    const a = inAngle - 0.9 + (i / (CONTACTS.length - 1)) * 1.8;
    const r = room.radius - 5;
    const pos = v3(cx + Math.cos(a) * r, 0, cz + Math.sin(a) * r);
    const pg = new THREE.Group();
    pg.position.copy(pos);
    pg.rotation.y = Math.atan2(cx - pos.x, cz - pos.z);

    const col = new THREE.Mesh(track(new THREE.BoxGeometry(1.6, 3.4, 0.35)), blackGlass(0.1));
    col.position.y = 1.7;
    col.castShadow = true;
    pg.add(col);
    const edge = new THREE.Mesh(track(new THREE.BoxGeometry(1.68, 0.06, 0.4)), glowMaterial(CONFIG.goldLight, 0.9));
    edge.position.y = 3.4;
    pg.add(edge);

    const label = makeLabel(c.label, { sub: c.value, size: 58, scale: 3.6 });
    label.position.y = 4.4;
    (label.material as THREE.SpriteMaterial).opacity = 0.4;
    pg.add(label);

    const l = new THREE.PointLight(CONFIG.goldColor, 1.5, 8, 2);
    l.position.set(0, 2.4, 0.6);
    pg.add(l);
    ctx.root.add(pg);

    let a2 = 0;
    ctx.register({
      id: `contact-${c.id}`,
      room: 'contact',
      kind: 'panel',
      object: pg,
      position: pos.clone(),
      title: c.label,
      prompt: 'CONNECT',
      payload: c,
      update: (dt, t, near) => {
        a2 += (near - a2) * Math.min(1, dt * 3.2);
        (label.material as THREE.SpriteMaterial).opacity = 0.35 + a2 * 0.65;
        label.position.y = 4.4 + Math.sin(t * 1.3 + i) * 0.08;
        l.intensity = 1 + a2 * 9;
        (edge.material as THREE.MeshBasicMaterial).opacity = 0.6 + a2 * 0.4;
        col.position.y = 1.7 + Math.sin(t * 0.9 + i) * 0.03;
      },
    });
  });
};

/* ---------- ROOM 07 — SECRET ---------- */
export const buildSecret = (ctx: BuildCtx) => {
  const room = roomById('secret');
  const [cx, cz] = [room.center[0], -room.center[1]];
  const g = new THREE.Group();
  g.name = 'secret-room';
  g.visible = false;

  const subCtx: BuildCtx = { ...ctx, root: g };
  buildFloorDisc(subCtx, cx, cz, room.radius, 8);
  buildPillars(subCtx, cx, cz, room.radius - 1.2, 9, 12, [Math.atan2(-cz, -cx)]);

  const title = makeLabel('SECTOR VII', { sub: 'CLASSIFIED', size: 92, scale: 10 });
  title.position.set(cx, 11, cz);
  g.add(title);

  // monolith
  const mono = new THREE.Mesh(
    track(new THREE.BoxGeometry(2.4, 8, 0.7)),
    track(new THREE.MeshStandardMaterial({ color: 0x030303, metalness: 1, roughness: 0.05 }))
  );
  mono.position.set(cx, 4, cz);
  mono.castShadow = true;
  g.add(mono);
  const monoEdge = new THREE.Mesh(track(new THREE.BoxGeometry(2.5, 8.1, 0.05)), glowMaterial(CONFIG.goldLight, 0.35));
  monoEdge.position.set(cx, 4, cz + 0.37);
  g.add(monoEdge);

  const rings: THREE.Mesh[] = [];
  for (let i = 0; i < 5; i++) {
    const r = new THREE.Mesh(track(new THREE.TorusGeometry(3.4 + i * 0.55, 0.025, 6, 70)), glowMaterial(CONFIG.goldLight, 0.5));
    r.position.set(cx, 4 + (i - 2) * 1.4, cz);
    r.rotation.x = Math.PI / 2 + (Math.random() - 0.5) * 0.5;
    g.add(r);
    rings.push(r);
  }
  const l = new THREE.PointLight(CONFIG.goldLight, 14, 34, 2);
  l.position.set(cx, 5, cz);
  g.add(l);

  ctx.root.add(g);

  ctx.register({
    id: 'secret-monolith',
    room: 'secret',
    kind: 'secret',
    object: mono,
    position: v3(cx, 0, cz),
    title: 'THE MONOLITH',
    prompt: 'DECRYPT',
    update: (dt, t, near) => {
      rings.forEach((r, i) => {
        r.rotation.z += dt * (0.15 + i * 0.07);
        r.position.y = 4 + (i - 2) * 1.4 + Math.sin(t * 0.6 + i) * 0.3;
        (r.material as THREE.MeshBasicMaterial).opacity = 0.35 + near * 0.45 + Math.sin(t * 2 + i) * 0.05;
      });
      mono.rotation.y += dt * 0.06;
      monoEdge.rotation.y = mono.rotation.y;
      monoEdge.position.set(cx + Math.sin(mono.rotation.y) * 0.37, 4, cz + Math.cos(mono.rotation.y) * 0.37);
      l.intensity = 10 + Math.sin(t * 1.5) * 3 + near * 14;
      title.position.y = 11 + Math.sin(t * 0.5) * 0.2;
    },
  });

  return g;
};

/* ---------- NPC ---------- */
export const buildNPC = (ctx: BuildCtx) => {
  const g = new THREE.Group();
  const pos = v3(6.5, 0, 7.5);
  g.position.copy(pos);

  const body = new THREE.Mesh(track(new THREE.CapsuleGeometry(0.42, 0.5, 6, 16)), blackGlass(0.15, 1));
  body.position.y = 1.7;
  body.castShadow = true;
  g.add(body);
  const headG = new THREE.Group();
  headG.position.y = 2.5;
  g.add(headG);
  const head = new THREE.Mesh(track(new THREE.SphereGeometry(0.34, 20, 16)), blackGlass(0.08, 1));
  headG.add(head);
  const eye = new THREE.Mesh(track(new THREE.TorusGeometry(0.17, 0.05, 8, 24)), glowMaterial(CONFIG.goldLight, 1));
  eye.position.z = 0.28;
  headG.add(eye);
  const collar = new THREE.Mesh(track(new THREE.TorusGeometry(0.46, 0.03, 6, 30)), goldMaterial({ emissiveIntensity: 1 }));
  collar.rotation.x = Math.PI / 2;
  collar.position.y = 1.25;
  g.add(collar);
  const orbit = new THREE.Mesh(track(new THREE.TorusGeometry(0.8, 0.02, 6, 40)), glowMaterial(CONFIG.goldSoft, 0.6));
  orbit.position.y = 1.8;
  orbit.rotation.x = Math.PI / 2.4;
  g.add(orbit);
  const light = new THREE.PointLight(CONFIG.goldLight, 3, 10, 2);
  light.position.y = 2.2;
  g.add(light);

  const label = makeLabel('UNIT V-01', { sub: 'GUIDE', size: 60, scale: 3.2 });
  label.position.y = 3.5;
  (label.material as THREE.SpriteMaterial).opacity = 0.5;
  g.add(label);

  ctx.root.add(g);

  ctx.register({
    id: 'npc-guide',
    room: 'hub',
    kind: 'npc',
    object: g,
    position: pos.clone(),
    title: 'UNIT V-01',
    prompt: 'TALK',
    update: (dt: number, t: number, near: number) => {
      void dt;
      g.position.y = Math.sin(t * 1.1) * 0.18 + 0.2;
      body.rotation.y = Math.sin(t * 0.4) * 0.2;
      orbit.rotation.z += dt * 0.6;
      orbit.rotation.y += dt * 0.25;
      light.intensity = 2.4 + near * 8;
      (label.material as THREE.SpriteMaterial).opacity = 0.4 + near * 0.6;
      (eye.material as THREE.MeshBasicMaterial).opacity = 0.75 + Math.sin(t * 3) * 0.2;
    },
  });
  return g;
};
