/* =========================================================================
   CHARACTER SYSTEM — procedural luxury avatar + optional GLB replacement
   ========================================================================= */
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { CONFIG } from './config';
import { glowMaterial, glowTexture, goldMaterial, track } from './gfx';

export type CharState = 'idle' | 'walk' | 'run' | 'jump' | 'interact';

const bodyMat = () =>
  track(new THREE.MeshStandardMaterial({ color: 0x0c0c0c, metalness: 0.95, roughness: 0.28 }));
const suitMat = () =>
  track(new THREE.MeshStandardMaterial({ color: 0x141414, metalness: 0.7, roughness: 0.42 }));
const whiteMat = () =>
  track(
    new THREE.MeshStandardMaterial({
      color: 0xf5f5f5,
      metalness: 0.2,
      roughness: 0.35,
      emissive: new THREE.Color(0x222222),
    })
  );

export class Character {
  group = new THREE.Group();
  private rig = new THREE.Group();
  private hips = new THREE.Group();
  private torso = new THREE.Group();
  private head = new THREE.Group();
  private armL = new THREE.Group();
  private armR = new THREE.Group();
  private foreL = new THREE.Group();
  private foreR = new THREE.Group();
  private legL = new THREE.Group();
  private legR = new THREE.Group();
  private shinL = new THREE.Group();
  private shinR = new THREE.Group();
  private aura!: THREE.Mesh;
  private auraGlow!: THREE.Sprite;
  private visor!: THREE.Mesh;

  private phase = 0;
  private blend = 0; // 0 idle → 1 locomotion
  private jumpBlend = 0;
  private interactT = 0;
  state: CharState = 'idle';
  stepEvent = 0; // increments each footfall
  private lastStepPhase = 0;

  // GLB support
  private mixer: THREE.AnimationMixer | null = null;
  private actions: Record<string, THREE.AnimationAction> = {};
  private current = '';
  usingModel = false;

  constructor() {
    this.buildProcedural();
    this.group.add(this.rig);
    if (CONFIG.characterModelUrl) this.loadModel(CONFIG.characterModelUrl);
  }

  /* ------------- procedural rig ------------- */
  private buildProcedural() {
    const black = bodyMat();
    const suit = suitMat();
    const white = whiteMat();
    const gold = goldMaterial({ emissiveIntensity: 0.5 });
    const goldBright = goldMaterial({ emissive: CONFIG.goldLight, emissiveIntensity: 1.2, rough: 0.15 });

    const box = (w: number, h: number, d: number, m: THREE.Material) =>
      new THREE.Mesh(track(new THREE.BoxGeometry(w, h, d)), m);

    // hips
    this.hips.position.y = 0.95;
    this.rig.add(this.hips);
    const pelvis = new THREE.Mesh(track(new THREE.CapsuleGeometry(0.2, 0.16, 4, 12)), suit);
    pelvis.rotation.z = Math.PI / 2;
    pelvis.castShadow = true;
    this.hips.add(pelvis);
    const belt = new THREE.Mesh(track(new THREE.TorusGeometry(0.24, 0.028, 8, 24)), gold);
    belt.rotation.x = Math.PI / 2;
    this.hips.add(belt);

    // torso
    this.torso.position.y = 0.1;
    this.hips.add(this.torso);
    const chest = new THREE.Mesh(track(new THREE.CapsuleGeometry(0.26, 0.34, 6, 16)), black);
    chest.position.y = 0.3;
    chest.castShadow = true;
    this.torso.add(chest);
    const plate = box(0.34, 0.4, 0.16, white);
    plate.position.set(0, 0.34, 0.15);
    this.torso.add(plate);
    const emblem = new THREE.Mesh(track(new THREE.OctahedronGeometry(0.075)), goldBright);
    emblem.position.set(0, 0.4, 0.24);
    this.torso.add(emblem);
    const collar = new THREE.Mesh(track(new THREE.TorusGeometry(0.19, 0.024, 8, 20)), gold);
    collar.position.y = 0.56;
    collar.rotation.x = Math.PI / 2;
    this.torso.add(collar);

    // head
    this.head.position.y = 0.76;
    this.torso.add(this.head);
    const skull = new THREE.Mesh(track(new THREE.SphereGeometry(0.2, 20, 16)), black);
    skull.scale.set(0.94, 1.08, 1);
    skull.castShadow = true;
    this.head.add(skull);
    this.visor = new THREE.Mesh(track(new THREE.BoxGeometry(0.3, 0.075, 0.06)), goldBright);
    this.visor.position.set(0, 0.02, 0.17);
    this.head.add(this.visor);
    const crown = new THREE.Mesh(track(new THREE.TorusGeometry(0.185, 0.017, 8, 24)), gold);
    crown.rotation.x = Math.PI / 2.1;
    crown.position.y = 0.13;
    this.head.add(crown);

    // shoulders + arms
    const makeArm = (side: 1 | -1, upper: THREE.Group, fore: THREE.Group) => {
      upper.position.set(0.31 * side, 0.5, 0);
      this.torso.add(upper);
      const pad = new THREE.Mesh(track(new THREE.SphereGeometry(0.115, 14, 12)), gold);
      upper.add(pad);
      const ua = new THREE.Mesh(track(new THREE.CapsuleGeometry(0.072, 0.26, 4, 10)), suit);
      ua.position.y = -0.19;
      ua.castShadow = true;
      upper.add(ua);
      fore.position.y = -0.36;
      upper.add(fore);
      const fa = new THREE.Mesh(track(new THREE.CapsuleGeometry(0.062, 0.24, 4, 10)), black);
      fa.position.y = -0.17;
      fore.add(fa);
      const cuff = new THREE.Mesh(track(new THREE.TorusGeometry(0.075, 0.018, 8, 16)), gold);
      cuff.position.y = -0.31;
      cuff.rotation.x = Math.PI / 2;
      fore.add(cuff);
      const hand = new THREE.Mesh(track(new THREE.SphereGeometry(0.062, 12, 10)), white);
      hand.position.y = -0.36;
      fore.add(hand);
    };
    makeArm(1, this.armR, this.foreR);
    makeArm(-1, this.armL, this.foreL);

    // legs
    const makeLeg = (side: 1 | -1, thigh: THREE.Group, shin: THREE.Group) => {
      thigh.position.set(0.14 * side, 0, 0);
      this.hips.add(thigh);
      const th = new THREE.Mesh(track(new THREE.CapsuleGeometry(0.095, 0.32, 4, 10)), suit);
      th.position.y = -0.23;
      th.castShadow = true;
      thigh.add(th);
      shin.position.y = -0.45;
      thigh.add(shin);
      const sh = new THREE.Mesh(track(new THREE.CapsuleGeometry(0.08, 0.3, 4, 10)), black);
      sh.position.y = -0.2;
      shin.add(sh);
      const knee = new THREE.Mesh(track(new THREE.TorusGeometry(0.095, 0.02, 8, 16)), gold);
      knee.rotation.x = Math.PI / 2;
      shin.add(knee);
      const foot = new THREE.Mesh(track(new THREE.BoxGeometry(0.15, 0.08, 0.3)), white);
      foot.position.set(0, -0.42, 0.06);
      shin.add(foot);
      const sole = new THREE.Mesh(track(new THREE.BoxGeometry(0.155, 0.02, 0.31)), goldBright);
      sole.position.set(0, -0.47, 0.06);
      shin.add(sole);
    };
    makeLeg(1, this.legR, this.shinR);
    makeLeg(-1, this.legL, this.shinL);

    // aura ring + ground glow
    this.aura = new THREE.Mesh(track(new THREE.TorusGeometry(0.62, 0.012, 6, 48)), glowMaterial(CONFIG.goldLight, 0.75));
    this.aura.rotation.x = Math.PI / 2;
    this.aura.position.y = 0.04;
    this.rig.add(this.aura);

    const spriteMat = track(
      new THREE.SpriteMaterial({
        map: glowTexture(),
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        opacity: 0.5,
        toneMapped: false,
      })
    );
    this.auraGlow = new THREE.Sprite(spriteMat);
    this.auraGlow.scale.set(3.2, 3.2, 1);
    this.auraGlow.position.y = 0.05;
    this.rig.add(this.auraGlow);

    // personal light
    const pl = new THREE.PointLight(CONFIG.goldLight, 6, 12, 2);
    pl.position.set(0, 1.6, 0);
    this.rig.add(pl);
  }

  /* ------------- optional GLB ------------- */
  private loadModel(url: string) {
    const loader = new GLTFLoader();
    loader.load(
      url,
      (gltf) => {
        const model = gltf.scene;
        model.scale.setScalar(CONFIG.characterModelScale);
        model.traverse((o) => {
          const m = o as THREE.Mesh;
          if (m.isMesh) {
            m.castShadow = true;
            m.receiveShadow = true;
          }
        });
        this.rig.visible = false;
        this.group.add(model);
        this.usingModel = true;
        if (gltf.animations?.length) {
          this.mixer = new THREE.AnimationMixer(model);
          gltf.animations.forEach((clip) => {
            const key = clip.name.toLowerCase();
            const action = this.mixer!.clipAction(clip);
            if (key.includes('idle')) this.actions.idle = action;
            else if (key.includes('run')) this.actions.run = action;
            else if (key.includes('walk')) this.actions.walk = action;
            else if (key.includes('jump')) this.actions.jump = action;
            else this.actions[key] = action;
          });
          this.playModelClip('idle');
        }
      },
      undefined,
      () => {
        /* keep procedural avatar on failure */
      }
    );
  }

  private playModelClip(name: string) {
    const next = this.actions[name];
    if (!next || this.current === name) return;
    const prev = this.actions[this.current];
    next.reset().fadeIn(0.25).play();
    prev?.fadeOut(0.25);
    this.current = name;
  }

  triggerInteract() {
    this.interactT = 1;
  }

  /**
   * @param speed01 horizontal speed normalised to run speed
   * @param grounded whether the character touches the floor
   */
  update(dt: number, speed01: number, grounded: boolean, running: boolean) {
    const t = performance.now() * 0.001;

    if (this.interactT > 0) this.interactT = Math.max(0, this.interactT - dt * 1.1);
    this.state = !grounded ? 'jump' : this.interactT > 0 ? 'interact' : speed01 > 0.55 ? 'run' : speed01 > 0.04 ? 'walk' : 'idle';

    if (this.mixer) {
      this.mixer.update(dt);
      this.playModelClip(!grounded ? 'jump' : speed01 > 0.55 ? 'run' : speed01 > 0.04 ? 'walk' : 'idle');
    }

    // blend factors (smooth acceleration / deceleration of the pose)
    this.blend += (Math.min(1, speed01 * 1.7) - this.blend) * Math.min(1, dt * 9);
    this.jumpBlend += ((grounded ? 0 : 1) - this.jumpBlend) * Math.min(1, dt * 9);

    // gait phase — faster when running
    const freq = running ? 12.5 : 8.2;
    this.phase += dt * freq * Math.max(0.12, this.blend);
    if (this.blend > 0.15 && grounded) {
      const cyc = Math.floor(this.phase / Math.PI);
      if (cyc !== this.lastStepPhase) {
        this.lastStepPhase = cyc;
        this.stepEvent++;
      }
    }

    if (this.usingModel) return;

    const p = this.phase;
    const b = this.blend;
    const swing = Math.sin(p);
    const swing2 = Math.sin(p * 2);

    // idle breathing
    const breath = Math.sin(t * 1.6) * 0.022;
    this.torso.position.y = 0.1 + breath * (1 - b) + Math.abs(swing2) * 0.035 * b;
    this.torso.rotation.y = swing * 0.12 * b;
    this.torso.rotation.x = 0.16 * b;
    this.hips.position.y = 0.95 - Math.abs(swing2) * 0.05 * b - this.jumpBlend * 0.06;
    this.hips.rotation.y = -swing * 0.1 * b;
    this.head.rotation.x = Math.sin(t * 0.9) * 0.05 * (1 - b) - 0.1 * b;
    this.head.rotation.y = Math.sin(t * 0.5) * 0.18 * (1 - b) - swing * 0.06 * b;

    // arms
    const armSwing = swing * (0.95 * b);
    const idleArm = 0.06 + Math.sin(t * 1.5) * 0.04;
    this.armR.rotation.x = -armSwing + idleArm * (1 - b);
    this.armL.rotation.x = armSwing + idleArm * (1 - b);
    this.armR.rotation.z = -0.12 - 0.1 * b;
    this.armL.rotation.z = 0.12 + 0.1 * b;
    this.foreR.rotation.x = -Math.max(0, -armSwing) * 0.8 - 0.15 * b;
    this.foreL.rotation.x = -Math.max(0, armSwing) * 0.8 - 0.15 * b;

    // legs
    this.legR.rotation.x = armSwing * 0.95;
    this.legL.rotation.x = -armSwing * 0.95;
    this.shinR.rotation.x = Math.max(0, -Math.sin(p + 0.7)) * 1.1 * b;
    this.shinL.rotation.x = Math.max(0, -Math.sin(p + Math.PI + 0.7)) * 1.1 * b;

    // jump pose
    if (this.jumpBlend > 0.01) {
      const j = this.jumpBlend;
      this.legR.rotation.x += -0.9 * j;
      this.legL.rotation.x += -0.4 * j;
      this.shinR.rotation.x += 1.3 * j;
      this.shinL.rotation.x += 0.5 * j;
      this.armR.rotation.x += -1.5 * j;
      this.armL.rotation.x += -1.7 * j;
      this.torso.rotation.x += -0.15 * j;
    }

    // interaction pose (reach forward)
    if (this.interactT > 0) {
      const k = Math.sin(this.interactT * Math.PI);
      this.armR.rotation.x += -1.35 * k;
      this.foreR.rotation.x += -0.5 * k;
      this.torso.rotation.x += 0.1 * k;
    }

    // aura pulse
    const pulse = 1 + Math.sin(t * 2.2) * 0.06 + b * 0.08;
    this.aura.scale.setScalar(pulse);
    (this.aura.material as THREE.MeshBasicMaterial).opacity = 0.4 + Math.sin(t * 2.2) * 0.12 + b * 0.25;
    this.auraGlow.scale.setScalar(3.1 * pulse);
    (this.visor.material as THREE.MeshStandardMaterial).emissiveIntensity = 1 + Math.sin(t * 3.1) * 0.35;
  }
}
