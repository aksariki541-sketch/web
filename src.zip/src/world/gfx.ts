/* =========================================================================
   GFX UTILS — procedural textures, materials, holographic labels
   ========================================================================= */
import * as THREE from 'three';
import { CONFIG } from './config';

export const GOLD = new THREE.Color(CONFIG.goldColor);
export const GOLD_LIGHT = new THREE.Color(CONFIG.goldLight);
export const GOLD_DEEP = new THREE.Color(CONFIG.goldDeep);
export const WHITE = new THREE.Color(CONFIG.whiteColor);

const disposables: { dispose: () => void }[] = [];
export const track = <T extends { dispose: () => void }>(o: T): T => {
  disposables.push(o);
  return o;
};
export const disposeAll = () => {
  disposables.forEach((d) => d.dispose());
  disposables.length = 0;
};

/* ---------- MATERIALS ---------- */
export const goldMaterial = (opts: { emissive?: number; rough?: number; emissiveIntensity?: number } = {}) =>
  track(
    new THREE.MeshStandardMaterial({
      color: CONFIG.goldColor,
      metalness: 1,
      roughness: opts.rough ?? 0.22,
      emissive: new THREE.Color(opts.emissive ?? CONFIG.goldDeep),
      emissiveIntensity: opts.emissiveIntensity ?? 0.18,
    })
  );

export const glowMaterial = (color = CONFIG.goldLight, opacity = 1) =>
  track(
    new THREE.MeshBasicMaterial({
      color,
      transparent: true,
      opacity,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    })
  );

export const blackGlass = (rough = 0.08, metal = 0.9) =>
  track(new THREE.MeshStandardMaterial({ color: 0x0a0a0a, metalness: metal, roughness: rough }));

export const darkMatte = (color = 0x111111, rough = 0.55) =>
  track(new THREE.MeshStandardMaterial({ color, metalness: 0.4, roughness: rough }));

/* ---------- CANVAS TEXTURE HELPERS ---------- */
const canvasTexture = (w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) => {
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const ctx = cv.getContext('2d')!;
  draw(ctx);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return track(tex);
};

/** Glossy black floor with gold concentric rings + grid. */
export const floorTexture = (rings = 6) =>
  canvasTexture(1024, 1024, (c) => {
    c.fillStyle = '#070707';
    c.fillRect(0, 0, 1024, 1024);
    const g = c.createRadialGradient(512, 512, 40, 512, 512, 512);
    g.addColorStop(0, 'rgba(212,175,55,0.18)');
    g.addColorStop(0.45, 'rgba(212,175,55,0.04)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g;
    c.fillRect(0, 0, 1024, 1024);
    c.strokeStyle = 'rgba(212,175,55,0.35)';
    c.lineWidth = 2;
    for (let i = 1; i <= rings; i++) {
      c.beginPath();
      c.arc(512, 512, (512 / rings) * i - 6, 0, Math.PI * 2);
      c.stroke();
    }
    c.strokeStyle = 'rgba(212,175,55,0.12)';
    c.lineWidth = 1;
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      c.beginPath();
      c.moveTo(512, 512);
      c.lineTo(512 + Math.cos(a) * 512, 512 + Math.sin(a) * 512);
      c.stroke();
    }
  });

/** Soft radial gold glow — used for portals, light pools, particles. */
export const glowTexture = (inner = 'rgba(245,215,110,1)', outer = 'rgba(212,175,55,0)') =>
  canvasTexture(256, 256, (c) => {
    const g = c.createRadialGradient(128, 128, 0, 128, 128, 128);
    g.addColorStop(0, inner);
    g.addColorStop(0.35, 'rgba(212,175,55,0.45)');
    g.addColorStop(1, outer);
    c.fillStyle = g;
    c.fillRect(0, 0, 256, 256);
  });

/** Portal energy surface. */
export const portalTexture = () =>
  canvasTexture(512, 512, (c) => {
    const g = c.createRadialGradient(256, 256, 10, 256, 256, 256);
    g.addColorStop(0, 'rgba(255,255,255,0.95)');
    g.addColorStop(0.18, 'rgba(245,215,110,0.8)');
    g.addColorStop(0.55, 'rgba(184,134,11,0.32)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g;
    c.fillRect(0, 0, 512, 512);
    c.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 90; i++) {
      const a = Math.random() * Math.PI * 2;
      const r = 30 + Math.random() * 210;
      c.fillStyle = `rgba(245,215,110,${Math.random() * 0.5})`;
      c.beginPath();
      c.arc(256 + Math.cos(a) * r, 256 + Math.sin(a) * r, Math.random() * 2.4, 0, Math.PI * 2);
      c.fill();
    }
  });

/* ---------- TEXT / PANEL TEXTURES ---------- */
type LabelOpts = {
  size?: number;
  color?: string;
  sub?: string;
  subColor?: string;
  letterSpacing?: number;
  bg?: boolean;
};

export const labelTexture = (text: string, opts: LabelOpts = {}) => {
  const size = opts.size ?? 72;
  const sub = opts.sub;
  const w = 1024;
  const h = 256;
  return canvasTexture(w, h, (c) => {
    c.clearRect(0, 0, w, h);
    if (opts.bg) {
      c.fillStyle = 'rgba(5,5,5,0.72)';
      c.fillRect(80, 60, w - 160, h - 120);
      c.strokeStyle = 'rgba(212,175,55,0.7)';
      c.lineWidth = 2;
      c.strokeRect(80, 60, w - 160, h - 120);
    }
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.shadowColor = 'rgba(212,175,55,0.85)';
    c.shadowBlur = 26;
    c.fillStyle = opts.color ?? '#ffffff';
    c.font = `600 ${size}px "Helvetica Neue", Arial, sans-serif`;
    const spaced = (opts.letterSpacing ?? 8) > 0 ? text.split('').join(String.fromCharCode(8202)) : text;
    c.fillText(spaced, w / 2, sub ? h / 2 - 26 : h / 2);
    if (sub) {
      c.shadowBlur = 10;
      c.fillStyle = opts.subColor ?? 'rgba(212,175,55,0.95)';
      c.font = `400 ${size * 0.42}px "Helvetica Neue", Arial, sans-serif`;
      c.fillText(sub.split('').join(String.fromCharCode(8202)), w / 2, h / 2 + 44);
    }
  });
};

/** Holographic information panel with title + wrapped body text. */
export const panelTexture = (title: string, subtitle: string, body: string, accent = '#d4af37') =>
  canvasTexture(1024, 640, (c) => {
    c.fillStyle = 'rgba(6,6,6,0.86)';
    c.fillRect(0, 0, 1024, 640);
    // frame
    c.strokeStyle = accent;
    c.lineWidth = 4;
    c.strokeRect(18, 18, 988, 604);
    c.strokeStyle = 'rgba(212,175,55,0.28)';
    c.lineWidth = 1;
    c.strokeRect(38, 38, 948, 564);
    // corner marks
    c.strokeStyle = accent;
    c.lineWidth = 6;
    const corner = (x: number, y: number, dx: number, dy: number) => {
      c.beginPath();
      c.moveTo(x + 46 * dx, y);
      c.lineTo(x, y);
      c.lineTo(x, y + 46 * dy);
      c.stroke();
    };
    corner(18, 18, 1, 1);
    corner(1006, 18, -1, 1);
    corner(18, 622, 1, -1);
    corner(1006, 622, -1, -1);

    c.textAlign = 'left';
    c.fillStyle = accent;
    c.font = '400 26px "Helvetica Neue", Arial, sans-serif';
    c.fillText(subtitle.split('').join(String.fromCharCode(8202)), 84, 116);
    c.fillStyle = '#ffffff';
    c.shadowColor = 'rgba(255,255,255,0.4)';
    c.shadowBlur = 18;
    c.font = '600 72px "Helvetica Neue", Arial, sans-serif';
    c.fillText(title, 80, 196);
    c.shadowBlur = 0;

    c.fillStyle = accent;
    c.fillRect(84, 244, 200, 3);

    c.fillStyle = 'rgba(237,237,237,0.92)';
    c.font = '300 32px "Helvetica Neue", Arial, sans-serif';
    const words = body.split(' ');
    let line = '';
    let y = 316;
    words.forEach((wd) => {
      const test = line + wd + ' ';
      if (c.measureText(test).width > 856) {
        c.fillText(line, 84, y);
        line = wd + ' ';
        y += 46;
      } else line = test;
    });
    c.fillText(line, 84, y);
  });

/** Project card face texture. */
export const cardTexture = (name: string, year: string, desc: string, tech: string[]) =>
  canvasTexture(768, 1024, (c) => {
    const g = c.createLinearGradient(0, 0, 0, 1024);
    g.addColorStop(0, 'rgba(14,14,14,0.95)');
    g.addColorStop(1, 'rgba(5,5,5,0.98)');
    c.fillStyle = g;
    c.fillRect(0, 0, 768, 1024);
    c.strokeStyle = '#d4af37';
    c.lineWidth = 3;
    c.strokeRect(16, 16, 736, 992);

    c.textAlign = 'left';
    c.fillStyle = 'rgba(212,175,55,0.9)';
    c.font = '400 28px "Helvetica Neue", Arial, sans-serif';
    c.fillText(year, 64, 110);

    c.fillStyle = '#ffffff';
    c.shadowColor = 'rgba(212,175,55,0.6)';
    c.shadowBlur = 22;
    c.font = '600 58px "Helvetica Neue", Arial, sans-serif';
    const nameWords = name.split(' ');
    let ny = 190;
    nameWords.forEach((w) => {
      c.fillText(w, 64, ny);
      ny += 66;
    });
    c.shadowBlur = 0;

    c.fillStyle = '#d4af37';
    c.fillRect(64, ny + 6, 160, 3);

    c.fillStyle = 'rgba(207,207,207,0.9)';
    c.font = '300 30px "Helvetica Neue", Arial, sans-serif';
    let line = '';
    let y = ny + 84;
    desc.split(' ').forEach((wd) => {
      const t = line + wd + ' ';
      if (c.measureText(t).width > 620) {
        c.fillText(line, 64, y);
        line = wd + ' ';
        y += 42;
      } else line = t;
    });
    c.fillText(line, 64, y);

    // tech chips
    let cx = 64;
    let cy = 880;
    c.font = '400 24px "Helvetica Neue", Arial, sans-serif';
    tech.forEach((t) => {
      const w = c.measureText(t).width + 36;
      if (cx + w > 704) {
        cx = 64;
        cy += 54;
      }
      c.strokeStyle = 'rgba(212,175,55,0.6)';
      c.lineWidth = 1.5;
      c.strokeRect(cx, cy - 30, w, 44);
      c.fillStyle = 'rgba(245,215,110,0.95)';
      c.fillText(t, cx + 18, cy - 2);
      cx += w + 14;
    });

    c.fillStyle = 'rgba(212,175,55,0.75)';
    c.font = '400 22px "Helvetica Neue", Arial, sans-serif';
    c.fillText('[ E ]  OPEN DOSSIER', 64, 1000 - 24);
  });

/* ---------- SPRITE LABEL ---------- */
export const makeLabel = (
  text: string,
  opts: LabelOpts & { scale?: number } = {}
): THREE.Sprite => {
  const tex = labelTexture(text, opts);
  const mat = track(
    new THREE.SpriteMaterial({
      map: tex,
      transparent: true,
      depthWrite: false,
      depthTest: true,
      opacity: 1,
      toneMapped: false,
    })
  );
  const s = new THREE.Sprite(mat);
  const scale = opts.scale ?? 4;
  s.scale.set(scale, scale * 0.25, 1);
  return s;
};

/* ---------- ENVIRONMENT (for metal reflections) ---------- */
export const buildEnvironment = (renderer: THREE.WebGLRenderer) => {
  const cv = document.createElement('canvas');
  cv.width = 512;
  cv.height = 256;
  const c = cv.getContext('2d')!;
  const g = c.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, '#000000');
  g.addColorStop(0.45, '#0b0a08');
  g.addColorStop(0.52, '#3a2c10');
  g.addColorStop(0.56, '#191308');
  g.addColorStop(1, '#000000');
  c.fillStyle = g;
  c.fillRect(0, 0, 512, 256);
  // warm gold highlights (fake studio lights)
  for (let i = 0; i < 5; i++) {
    const x = 40 + i * 105;
    const rg = c.createRadialGradient(x, 120, 4, x, 120, 90);
    rg.addColorStop(0, 'rgba(245,215,110,0.85)');
    rg.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = rg;
    c.fillRect(x - 90, 30, 180, 180);
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.mapping = THREE.EquirectangularReflectionMapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  const pmrem = new THREE.PMREMGenerator(renderer);
  const env = pmrem.fromEquirectangular(tex).texture;
  tex.dispose();
  pmrem.dispose();
  return track(env);
};
