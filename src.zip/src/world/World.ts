/* =========================================================================
   WORLD ENGINE — scene, camera, movement, interaction, cinematics
   ========================================================================= */
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';

import { CONFIG, ROOMS, RoomId, roomById, type Quality } from './config';
import { Character } from './character';
import { AudioSystem } from './audio';
import { buildEnvironment, disposeAll, glowTexture, track } from './gfx';
import {
  buildAbout,
  buildContact,
  buildExperience,
  buildHub,
  buildNPC,
  buildProjects,
  buildSecret,
  buildSkills,
  type BuildCtx,
  type Interactable,
} from './rooms';

export type WorldEvent =
  | { type: 'open'; kind: Interactable['kind']; id: string; title: string; payload: unknown }
  | { type: 'unlock-secret' }
  | { type: 'flash' }
  | { type: 'enter-room'; room: RoomId }
  | { type: 'quality'; quality: Quality };

export type WorldState = {
  room: RoomId;
  roomName: string;
  prompt: { title: string; action: string } | null;
  running: boolean;
  moving: boolean;
  cinematic: boolean;
  secretUnlocked: boolean;
  fps: number;
};

type Zone = { kind: 'disc'; x: number; z: number; r: number; id: RoomId } | {
  kind: 'seg';
  ax: number;
  az: number;
  bx: number;
  bz: number;
  hw: number;
  id: RoomId;
};

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const damp = (current: number, target: number, lambda: number, dt: number) =>
  THREE.MathUtils.lerp(current, target, 1 - Math.exp(-lambda * dt));

export class World {
  // core
  renderer!: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera!: THREE.PerspectiveCamera;
  composer: EffectComposer | null = null;
  bloomPass: UnrealBloomPass | null = null;
  container!: HTMLElement;
  clock = new THREE.Clock();
  audio = new AudioSystem();

  // world content
  root = new THREE.Group();
  character = new Character();
  interactables: Interactable[] = [];
  zones: Zone[] = [];
  secretGroup: THREE.Group | null = null;
  private particles: THREE.Points | null = null;
  private particleData: { speed: Float32Array; base: Float32Array } | null = null;
  private keyLight!: THREE.DirectionalLight;

  // movement state
  private velocity = new THREE.Vector3();
  private vy = 0;
  private grounded = true;
  private pos = new THREE.Vector3(0, 0, 12);
  private facing = Math.PI;
  private keys = new Set<string>();
  private joystick = { x: 0, y: 0 };
  private runFlag = false;
  private navQueue: THREE.Vector3[] = [];
  private navRoom: RoomId | null = null;

  // camera state
  private camYaw = 0;
  private camPitch = 0.22;
  private camDist = CONFIG.cameraDistance;
  private camPos = new THREE.Vector3(0, 8, 24);
  private camLook = new THREE.Vector3(0, 1.6, 0);
  private focusObj: THREE.Object3D | null = null;
  private focusBlend = 0;
  private introT = 0;
  private introActive = false;
  private dragging = false;
  private lastPointer = { x: 0, y: 0 };
  private pointerDownAt = { x: 0, y: 0, t: 0 };
  private raycaster = new THREE.Raycaster();

  // meta
  quality: Quality = CONFIG.graphicsQuality;
  secretUnlocked = false;
  currentRoom: RoomId = 'hub';
  private lastStep = 0;
  private stuckT = 0;
  private fpsAcc = 0;
  private fpsFrames = 0;
  private fpsTimer = 0;
  private lowFpsStreak = 0;
  private running = true;
  private disposed = false;
  private rafId = 0;

  onState: (s: Partial<WorldState>) => void = () => {};
  onEvent: (e: WorldEvent) => void = () => {};

  /* ================= SETUP ================= */
  async init(container: HTMLElement, quality: Quality, onProgress: (p: number, msg: string) => void) {
    this.container = container;
    this.quality = quality;

    const step = async (p: number, msg: string, fn: () => void) => {
      if (this.disposed) return;
      onProgress(p, msg);
      await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 40)));
      if (this.disposed) return;
      fn();
    };

    await step(6, 'INITIALIZING RENDER CORE...', () => {
      this.renderer = new THREE.WebGLRenderer({ antialias: quality !== 'low', powerPreference: 'high-performance' });
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, CONFIG.pixelRatio[quality]));
      this.renderer.setSize(container.clientWidth, container.clientHeight);
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.05;
      this.renderer.outputColorSpace = THREE.SRGBColorSpace;
      this.renderer.shadowMap.enabled = CONFIG.shadows[quality];
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      container.appendChild(this.renderer.domElement);
      this.renderer.domElement.style.display = 'block';
      this.renderer.domElement.style.touchAction = 'none';
    });

    await step(16, 'CALIBRATING OPTICS...', () => {
      this.camera = new THREE.PerspectiveCamera(
        CONFIG.cameraFov,
        container.clientWidth / container.clientHeight,
        0.1,
        400
      );
      this.camera.position.set(0, 26, 46);
      this.scene.background = new THREE.Color(CONFIG.backgroundColor);
      this.scene.fog = new THREE.FogExp2(CONFIG.backgroundColor, CONFIG.fogDensity);
      this.scene.environment = buildEnvironment(this.renderer);
      this.scene.add(this.root);
    });

    await step(26, 'IGNITING GOLD LIGHT...', () => {
      const amb = new THREE.AmbientLight(0xffffff, 0.22);
      this.scene.add(amb);
      const hemi = new THREE.HemisphereLight(CONFIG.goldLight, 0x000000, 0.5);
      this.scene.add(hemi);
      this.keyLight = new THREE.DirectionalLight(CONFIG.goldSoft, 1.5);
      this.keyLight.position.set(28, 46, 20);
      this.keyLight.castShadow = CONFIG.shadows[quality];
      this.keyLight.shadow.mapSize.set(1024, 1024);
      const cam = this.keyLight.shadow.camera as THREE.OrthographicCamera;
      cam.left = -60;
      cam.right = 60;
      cam.top = 60;
      cam.bottom = -60;
      cam.far = 160;
      this.scene.add(this.keyLight);
      const rim = new THREE.DirectionalLight(0xffffff, 0.35);
      rim.position.set(-30, 20, -30);
      this.scene.add(rim);
    });

    const ctx: BuildCtx = {
      root: this.root,
      register: (i) => this.interactables.push(i),
      quality,
    };

    await step(38, 'CONSTRUCTING MAIN HUB...', () => buildHub(ctx));
    await step(50, 'ASSEMBLING ABOUT MUSEUM...', () => buildAbout(ctx));
    await step(60, 'HANGING PROJECT GALLERY...', () => buildProjects(ctx));
    await step(70, 'POWERING SKILLS LAB...', () => buildSkills(ctx));
    await step(78, 'UNROLLING TIMELINE VAULT...', () => buildExperience(ctx));
    await step(85, 'OPENING CONTROL CENTER...', () => buildContact(ctx));
    await step(90, 'ENCRYPTING SECTOR VII...', () => {
      this.secretGroup = buildSecret(ctx);
      buildNPC(ctx);
    });

    await step(95, 'SPAWNING CHARACTER...', () => {
      this.scene.add(this.character.group);
      this.pos.set(0, 0, 13);
      this.character.group.position.copy(this.pos);
      this.buildZones();
      this.buildParticles();
      this.setupPostFX();
      this.bindEvents();
    });

    await step(100, 'SYSTEM READY.', () => {
      this.camPos.set(0, 30, 52);
      this.camera.position.copy(this.camPos);
      // hold the cinematic camera until the visitor enters
      this.introActive = true;
      this.introT = 0;
    });
  }

  private setupPostFX() {
    if (!CONFIG.bloom[this.quality]) {
      this.composer?.dispose();
      this.composer = null;
      this.bloomPass = null;
      return;
    }
    const composer = new EffectComposer(this.renderer);
    composer.addPass(new RenderPass(this.scene, this.camera));
    const bloom = new UnrealBloomPass(
      new THREE.Vector2(this.container.clientWidth, this.container.clientHeight),
      this.quality === 'high' ? 0.62 : 0.45,
      0.85,
      0.72
    );
    composer.addPass(bloom);
    composer.addPass(new OutputPass());
    composer.setSize(this.container.clientWidth, this.container.clientHeight);
    composer.setPixelRatio(Math.min(window.devicePixelRatio, CONFIG.pixelRatio[this.quality]));
    this.composer = composer;
    this.bloomPass = bloom;
  }

  /* ---------- walkable zones ---------- */
  private buildZones() {
    this.zones = [];
    ROOMS.forEach((r) => {
      this.zones.push({ kind: 'disc', x: r.center[0], z: -r.center[1], r: r.radius - 0.9, id: r.id });
      if (r.id === 'hub') return;
      const a = (r.angle * Math.PI) / 180;
      const hub = roomById('hub');
      this.zones.push({
        kind: 'seg',
        ax: Math.cos(a) * (hub.radius - 2),
        az: -Math.sin(a) * (hub.radius - 2),
        bx: r.center[0],
        bz: -r.center[1],
        hw: CONFIG.walkwayWidth / 2 - 0.5,
        id: r.id,
      });
    });
  }

  private zoneAt(x: number, z: number): Zone | null {
    for (const zn of this.zones) {
      if (zn.id === 'secret' && !this.secretUnlocked) continue;
      if (zn.kind === 'disc') {
        const dx = x - zn.x;
        const dz = z - zn.z;
        if (dx * dx + dz * dz <= zn.r * zn.r) return zn;
      } else {
        const abx = zn.bx - zn.ax;
        const abz = zn.bz - zn.az;
        const t = clamp(((x - zn.ax) * abx + (z - zn.az) * abz) / (abx * abx + abz * abz), 0, 1);
        const px = zn.ax + abx * t;
        const pz = zn.az + abz * t;
        const dx = x - px;
        const dz = z - pz;
        if (dx * dx + dz * dz <= zn.hw * zn.hw) return zn;
      }
    }
    return null;
  }

  private walkable(x: number, z: number) {
    return this.zoneAt(x, z) !== null;
  }

  /* ---------- particles ---------- */
  private buildParticles() {
    if (this.particles) {
      this.root.remove(this.particles);
      this.particles.geometry.dispose();
      this.particles = null;
    }
    const count = CONFIG.particleCount[this.quality];
    const positions = new Float32Array(count * 3);
    const speed = new Float32Array(count);
    const base = new Float32Array(count);
    const spread = CONFIG.roomDistance + 26;
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const r = Math.sqrt(Math.random()) * spread;
      positions[i * 3] = Math.cos(a) * r;
      positions[i * 3 + 1] = Math.random() * 26;
      positions[i * 3 + 2] = Math.sin(a) * r;
      speed[i] = 0.25 + Math.random() * 1.1;
      base[i] = Math.random() * Math.PI * 2;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = track(
      new THREE.PointsMaterial({
        size: 0.28,
        map: glowTexture(),
        color: new THREE.Color(CONFIG.goldLight),
        transparent: true,
        opacity: 0.75,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        sizeAttenuation: true,
        toneMapped: false,
      })
    );
    this.particles = new THREE.Points(geo, mat);
    this.particles.frustumCulled = false;
    this.root.add(this.particles);
    this.particleData = { speed, base };
  }

  /* ================= INPUT ================= */
  private bindEvents() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.onResize);
    const el = this.renderer.domElement;
    el.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    el.addEventListener('wheel', this.onWheel, { passive: true });
  }

  inputEnabled = true;

  setInputEnabled(v: boolean) {
    this.inputEnabled = v;
    if (!v) {
      this.keys.clear();
      this.joystick.x = 0;
      this.joystick.y = 0;
      this.runFlag = false;
    }
  }

  private onKeyDown = (e: KeyboardEvent) => {
    const tag = (e.target as HTMLElement)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || !this.inputEnabled) return;
    const k = e.key.toLowerCase();
    if (['w', 'a', 's', 'd', ' ', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) e.preventDefault();
    this.keys.add(k);
    if (k === ' ') this.jump();
    if (k === 'e') this.interact();
    if (k === 'shift') this.runFlag = true;
  };

  private onKeyUp = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    this.keys.delete(k);
    if (k === 'shift') this.runFlag = false;
  };

  private onResize = () => {
    if (!this.container || this.disposed) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.composer?.setSize(w, h);
  };

  private onPointerDown = (e: PointerEvent) => {
    this.dragging = true;
    this.lastPointer = { x: e.clientX, y: e.clientY };
    this.pointerDownAt = { x: e.clientX, y: e.clientY, t: performance.now() };
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.dragging) return;
    const dx = e.clientX - this.lastPointer.x;
    const dy = e.clientY - this.lastPointer.y;
    this.lastPointer = { x: e.clientX, y: e.clientY };
    this.camYaw -= dx * 0.005;
    this.camPitch = clamp(this.camPitch + dy * 0.003, -0.15, 0.9);
  };

  private onPointerUp = (e: PointerEvent) => {
    if (!this.dragging) return;
    this.dragging = false;
    const dist = Math.hypot(e.clientX - this.pointerDownAt.x, e.clientY - this.pointerDownAt.y);
    const dt = performance.now() - this.pointerDownAt.t;
    if (dist < 6 && dt < 450) this.handleClick(e);
  };

  private onWheel = (e: WheelEvent) => {
    this.camDist = clamp(this.camDist + e.deltaY * 0.01, 4.5, 20);
  };

  /** click → walk to point / walk to object and interact */
  private handleClick(e: PointerEvent) {
    if (!this.inputEnabled) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    const ndc = new THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1
    );
    this.raycaster.setFromCamera(ndc, this.camera);
    const hits = this.raycaster.intersectObjects([this.root], true);
    if (!hits.length) return;
    const hit = hits.find((h) => h.object.visible) ?? hits[0];

    // walk toward the click point when it lands on walkable ground
    const p = hit.point;
    const target = this.interactables.find((i) => {
      let o: THREE.Object3D | null = hit.object;
      while (o) {
        if (o === i.object) return true;
        o = o.parent;
      }
      return false;
    });

    if (target && !(target.hidden && !this.secretUnlocked)) {
      const dir = new THREE.Vector3().subVectors(this.pos, target.position).setY(0).normalize();
      const stand = target.position.clone().add(dir.multiplyScalar(3.2));
      if (this.walkable(stand.x, stand.z)) {
        this.navQueue = [stand];
        this.navRoom = null;
        this.pendingInteract = target.id;
        this.audio.click();
        return;
      }
    }
    if (this.walkable(p.x, p.z)) {
      this.navQueue = [new THREE.Vector3(p.x, 0, p.z)];
      this.navRoom = null;
      this.pendingInteract = null;
      this.audio.hover();
    }
  }

  private pendingInteract: string | null = null;

  /* ================= PUBLIC API ================= */
  setJoystick(x: number, y: number) {
    this.joystick.x = x;
    this.joystick.y = y;
    if (x !== 0 || y !== 0) this.navQueue = [];
  }

  orbit(dx: number, dy: number) {
    this.camYaw -= dx * 0.006;
    this.camPitch = clamp(this.camPitch + dy * 0.004, -0.15, 0.9);
  }

  setRun(v: boolean) {
    if (!this.inputEnabled && v) return;
    this.runFlag = v;
  }

  jump() {
    if (!this.inputEnabled) return;
    if (this.grounded) {
      this.vy = CONFIG.jumpForce;
      this.grounded = false;
      this.audio.jump();
    }
  }

  interact() {
    if (!this.inputEnabled || this.introActive) return;
    const t = this.nearestOverride ?? this.nearest;
    if (!t) return;
    this.character.triggerInteract();
    if (t.kind === 'portal' && t.target) {
      this.audio.portal();
      this.enterRoom(t.target);
      return;
    }
    if (t.kind === 'anomaly') {
      this.unlockSecret();
      return;
    }
    this.audio.hologram();
    this.focusObj = t.object;
    this.onEvent({ type: 'open', kind: t.kind, id: t.id, title: t.title, payload: t.payload });
  }

  unlockSecret() {
    if (this.secretUnlocked) return;
    this.secretUnlocked = true;
    this.audio.secret();
    if (this.secretGroup) this.secretGroup.visible = true;
    this.root.traverse((o) => {
      if (o.name === 'secret-walkway') o.visible = true;
    });
    const portal = this.interactables.find((i) => i.id === 'portal-secret');
    if (portal) {
      portal.hidden = false;
      portal.object.visible = true;
    }
    this.onEvent({ type: 'unlock-secret' });
    this.onState({ secretUnlocked: true });
  }

  /** cinematic travel to a room: walk to the portal, then into the chamber */
  enterRoom(id: RoomId) {
    if (id === 'secret' && !this.secretUnlocked) this.unlockSecret();
    const hub = roomById('hub');
    const path: THREE.Vector3[] = [];

    // 1 — leave the current chamber along its walkway back to the hub
    if (this.currentRoom !== 'hub' && this.currentRoom !== id) {
      const cur = roomById(this.currentRoom);
      const ca = (cur.angle * Math.PI) / 180;
      const cdir = new THREE.Vector3(-Math.cos(ca), 0, Math.sin(ca)); // room → hub
      path.push(
        new THREE.Vector3(cur.center[0], 0, -cur.center[1]).addScaledVector(cdir, cur.radius - 3)
      );
      path.push(new THREE.Vector3(-cdir.x, 0, -cdir.z).multiplyScalar(hub.radius - 3));
      path.push(new THREE.Vector3(0, 0, 0));
    }

    if (id === 'hub') {
      path.push(new THREE.Vector3(0, 0, 11));
    } else {
      const room = roomById(id);
      const a = (room.angle * Math.PI) / 180;
      const dir = new THREE.Vector3(Math.cos(a), 0, -Math.sin(a)); // hub → room
      const rc = new THREE.Vector3(room.center[0], 0, -room.center[1]);
      if (this.currentRoom !== id) {
        path.push(dir.clone().multiplyScalar(hub.radius - 2.5));
        path.push(rc.clone().addScaledVector(dir, -(room.radius - 3)));
      }
      path.push(rc.clone().addScaledVector(dir, -7.5));
    }
    this.navQueue = path;
    this.navRoom = id;
    this.focusObj = null;
    this.onEvent({ type: 'flash' });
    this.audio.door();
    this.onState({ cinematic: true });
  }

  clearFocus() {
    this.focusObj = null;
  }

  setQuality(q: Quality) {
    this.quality = q;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, CONFIG.pixelRatio[q]));
    this.renderer.shadowMap.enabled = CONFIG.shadows[q];
    this.keyLight.castShadow = CONFIG.shadows[q];
    this.buildParticles();
    this.setupPostFX();
    this.onResize();
    this.onEvent({ type: 'quality', quality: q });
  }

  startIntro() {
    this.introActive = true;
    this.introT = 0;
    this.onState({ cinematic: true });
  }

  start() {
    this.clock.start();
    this.loop();
  }

  /* ================= LOOP ================= */
  private loop = () => {
    if (this.disposed) return;
    this.rafId = requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    const t = this.clock.elapsedTime;
    if (!this.running) return;
    this.updateMovement(dt);
    this.updateCamera(dt, t);
    this.updateInteractables(dt, t);
    this.updateParticles(dt, t);
    this.render();
    this.trackFps(dt);
  };

  private render() {
    if (this.composer) this.composer.render();
    else this.renderer.render(this.scene, this.camera);
  }

  private trackFps(dt: number) {
    this.fpsAcc += dt;
    this.fpsFrames++;
    this.fpsTimer += dt;
    if (this.fpsTimer > 1) {
      const fps = Math.round(this.fpsFrames / this.fpsAcc);
      this.onState({ fps });
      if (fps < 34 && this.quality !== 'low') {
        this.lowFpsStreak++;
        if (this.lowFpsStreak >= 4) {
          this.lowFpsStreak = 0;
          this.setQuality(this.quality === 'high' ? 'medium' : 'low');
        }
      } else this.lowFpsStreak = 0;
      this.fpsAcc = 0;
      this.fpsFrames = 0;
      this.fpsTimer = 0;
    }
  }

  /* ---------- movement ---------- */
  private updateMovement(dt: number) {
    // input direction in camera space
    let ix = 0;
    let iz = 0;
    // freeze player control while the opening cinematic is playing
    if (!this.introActive && this.inputEnabled) {
      const k = this.keys;
      if (k.has('w') || k.has('arrowup')) iz -= 1;
      if (k.has('s') || k.has('arrowdown')) iz += 1;
      if (k.has('a') || k.has('arrowleft')) ix -= 1;
      if (k.has('d') || k.has('arrowright')) ix += 1;
      ix += this.joystick.x;
      iz += this.joystick.y;
    }

    let auto = false;
    if ((ix !== 0 || iz !== 0) && this.navQueue.length) {
      // the visitor takes back manual control — abort the cinematic route
      this.navQueue = [];
      this.navRoom = null;
      this.pendingInteract = null;
      this.onState({ cinematic: false });
    }

    const dir = new THREE.Vector3();
    if (ix !== 0 || iz !== 0) {
      const len = Math.min(1, Math.hypot(ix, iz));
      const yaw = this.camYaw;
      const forward = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));
      const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
      dir.addScaledVector(forward, iz).addScaledVector(right, ix).normalize().multiplyScalar(len);
    } else if (this.navQueue.length) {
      auto = true;
      const goal = this.navQueue[0];
      const to = new THREE.Vector3().subVectors(goal, this.pos).setY(0);
      if (to.length() < 1.4) {
        this.navQueue.shift();
        if (!this.navQueue.length) this.arriveNav();
      } else dir.copy(to.normalize()).multiplyScalar(this.navQueue.length > 1 ? 1 : Math.min(1, to.length() / 3));
    }

    const running = this.runFlag || (auto && this.navQueue.length > 1);
    const maxSpeed = running ? CONFIG.runSpeed : auto && this.navQueue.length > 1 ? CONFIG.runSpeed * 0.72 : CONFIG.characterSpeed;
    const desired = dir.multiplyScalar(maxSpeed);
    const accel = desired.lengthSq() > 0.01 ? CONFIG.acceleration : CONFIG.deceleration;
    this.velocity.x = damp(this.velocity.x, desired.x, accel, dt);
    this.velocity.z = damp(this.velocity.z, desired.z, accel, dt);
    if (this.velocity.lengthSq() < 0.0004) this.velocity.set(0, 0, 0);

    // gravity / jump
    this.vy -= CONFIG.gravity * dt;
    let ny = this.pos.y + this.vy * dt;
    if (ny <= 0) {
      if (!this.grounded) this.audio.land();
      ny = 0;
      this.vy = 0;
      this.grounded = true;
    }
    this.pos.y = ny;

    // horizontal with simple sliding collision against zone borders
    const nx = this.pos.x + this.velocity.x * dt;
    const nz = this.pos.z + this.velocity.z * dt;
    if (this.walkable(nx, nz)) {
      this.pos.x = nx;
      this.pos.z = nz;
    } else if (this.walkable(nx, this.pos.z)) {
      this.pos.x = nx;
      this.velocity.z *= 0.4;
    } else if (this.walkable(this.pos.x, nz)) {
      this.pos.z = nz;
      this.velocity.x *= 0.4;
    } else {
      this.velocity.multiplyScalar(0.2);
    }

    // smooth turning toward movement direction
    const speed = Math.hypot(this.velocity.x, this.velocity.z);
    if (speed > 0.35) {
      const targetFacing = Math.atan2(this.velocity.x, this.velocity.z);
      let diff = targetFacing - this.facing;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.facing += diff * Math.min(1, dt * CONFIG.turnSpeed);
    } else if (this.focusObj) {
      const to = new THREE.Vector3().subVectors(this.focusObj.getWorldPosition(new THREE.Vector3()), this.pos);
      const targetFacing = Math.atan2(to.x, to.z);
      let diff = targetFacing - this.facing;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.facing += diff * Math.min(1, dt * 4);
    }

    this.character.group.position.copy(this.pos);
    this.character.group.rotation.y = this.facing;
    const speed01 = speed / CONFIG.runSpeed;
    this.character.update(dt, speed01, this.grounded, running);

    // anti-stuck watchdog for cinematic routes
    if (auto) {
      if (speed < 0.8) {
        this.stuckT += dt;
        if (this.stuckT > 1.3) {
          this.stuckT = 0;
          this.navQueue.shift();
          if (!this.navQueue.length) this.arriveNav();
        }
      } else this.stuckT = 0;
    } else this.stuckT = 0;

    if (this.character.stepEvent !== this.lastStep) {
      this.lastStep = this.character.stepEvent;
      this.audio.step_(running);
    }

    // room tracking
    const zone = this.zoneAt(this.pos.x, this.pos.z);
    const roomNow: RoomId = zone ? (zone.kind === 'disc' ? zone.id : this.currentRoom) : this.currentRoom;
    if (zone?.kind === 'disc' && roomNow !== this.currentRoom) {
      this.currentRoom = roomNow;
      this.onState({ room: roomNow, roomName: roomById(roomNow).name });
      this.onEvent({ type: 'enter-room', room: roomNow });
    }

    // only broadcast when something actually changed (avoids per-frame React work)
    const movingNow = speed > 0.4;
    const runningNow = running && speed > 0.4;
    if (movingNow !== this.lastMoving || runningNow !== this.lastRunning) {
      this.lastMoving = movingNow;
      this.lastRunning = runningNow;
      this.onState({ moving: movingNow, running: runningNow });
    }
  }

  private lastMoving = false;
  private lastRunning = false;

  private arriveNav() {
    if (this.navRoom) {
      const room = this.navRoom;
      this.navRoom = null;
      const changed = this.currentRoom !== room;
      this.currentRoom = room;
      this.onState({ room, roomName: roomById(room).name, cinematic: false });
      if (changed) this.onEvent({ type: 'enter-room', room });
      this.audio.hologram();
    }
    if (this.pendingInteract) {
      const id = this.pendingInteract;
      this.pendingInteract = null;
      const target = this.interactables.find((i) => i.id === id);
      if (target) {
        this.nearestOverride = target;
        this.interact();
        this.nearestOverride = null;
      }
    }
  }

  /* ---------- camera ---------- */
  private updateCamera(dt: number, t: number) {
    const charPos = this.pos.clone();
    const lookTarget = charPos.clone().add(new THREE.Vector3(0, CONFIG.cameraLookHeight, 0));

    if (this.introActive) {
      this.introT += dt;
      const d = Math.min(1, this.introT / 7);
      const e = d < 0.5 ? 2 * d * d : 1 - Math.pow(-2 * d + 2, 2) / 2;
      const angle = -Math.PI * 0.9 + e * Math.PI * 0.9;
      const radius = THREE.MathUtils.lerp(62, CONFIG.cameraDistance, e);
      const height = THREE.MathUtils.lerp(34, CONFIG.cameraHeight, e);
      const desired = new THREE.Vector3(
        charPos.x + Math.sin(angle) * radius,
        height,
        charPos.z + Math.cos(angle) * radius
      );
      this.camPos.lerp(desired, 1 - Math.exp(-2.4 * dt));
      this.camLook.lerp(lookTarget.clone().lerp(new THREE.Vector3(0, 7, 0), 1 - e), 1 - Math.exp(-3 * dt));
      this.camera.position.copy(this.camPos);
      this.camera.lookAt(this.camLook);
      this.camYaw = Math.atan2(this.camPos.x - charPos.x, this.camPos.z - charPos.z);
      if (this.introT > 7) {
        this.introActive = false;
        this.onState({ cinematic: false });
      }
      return;
    }

    // focus mode: frame the object being inspected
    const focusing = !!this.focusObj;
    this.focusBlend = damp(this.focusBlend, focusing ? 1 : 0, 3, dt);

    const speed = Math.hypot(this.velocity.x, this.velocity.z);
    const runFactor = clamp(speed / CONFIG.runSpeed, 0, 1);
    const baseDist = THREE.MathUtils.lerp(this.camDist, CONFIG.cameraRunDistance, runFactor * 0.55);
    const navBoost = this.navQueue.length ? 2.4 : 0;

    let desiredPos: THREE.Vector3;
    let desiredLook = lookTarget.clone();

    if (focusing) {
      const fp = this.focusObj!.getWorldPosition(new THREE.Vector3());
      const mid = charPos.clone().lerp(fp, 0.55).add(new THREE.Vector3(0, 2.2, 0));
      const side = new THREE.Vector3().subVectors(charPos, fp).setY(0).normalize();
      desiredPos = mid.clone().add(side.multiplyScalar(6.2)).add(new THREE.Vector3(0, 2.4, 0));
      desiredLook = mid;
      this.camYaw = Math.atan2(desiredPos.x - charPos.x, desiredPos.z - charPos.z);
    } else {
      const dist = baseDist + navBoost + Math.sin(t * 0.4) * 0.12;
      const height = CONFIG.cameraHeight + this.camPitch * 6 + navBoost * 0.4;
      desiredPos = new THREE.Vector3(
        charPos.x + Math.sin(this.camYaw) * dist * Math.cos(this.camPitch),
        charPos.y + height,
        charPos.z + Math.cos(this.camYaw) * dist * Math.cos(this.camPitch)
      );
      desiredLook.add(new THREE.Vector3(0, runFactor * 0.4, 0));
      // small handheld sway keeps the world cinematic
      desiredPos.x += Math.sin(t * 0.53) * 0.08;
      desiredPos.y += Math.sin(t * 0.71) * 0.06;
    }

    const lambda = focusing ? 3.2 : CONFIG.cameraSmoothness + runFactor * 1.4;
    this.camPos.lerp(desiredPos, 1 - Math.exp(-lambda * dt));
    this.camLook.lerp(desiredLook, 1 - Math.exp(-(lambda + 1.5) * dt));
    this.camera.position.copy(this.camPos);
    this.camera.lookAt(this.camLook);
    const targetFov = CONFIG.cameraFov + runFactor * 6 - this.focusBlend * 8;
    this.camera.fov = damp(this.camera.fov, targetFov, 3, dt);
    this.camera.updateProjectionMatrix();
  }

  /* ---------- interactables & proximity ---------- */
  private nearest: Interactable | null = null;
  private nearestOverride: Interactable | null = null;

  private updateInteractables(dt: number, t: number) {
    let best: Interactable | null = null;
    let bestD = Infinity;
    for (const i of this.interactables) {
      if (i.hidden && !this.secretUnlocked) continue;
      const d = i.position.distanceTo(this.pos);
      const near = clamp(1 - (d - CONFIG.interactDistance) / (CONFIG.proximityDistance - CONFIG.interactDistance), 0, 1);
      i.update?.(dt, t, near);
      if (d < CONFIG.interactDistance + 1.6 && d < bestD) {
        bestD = d;
        best = i;
      }
    }
    if (best !== this.nearest) {
      this.nearest = best;
      this.onState({ prompt: best ? { title: best.title, action: best.prompt } : null });
      if (best) this.audio.hover();
    }
  }

  private updateParticles(dt: number, t: number) {
    if (!this.particles || !this.particleData) return;
    const pos = this.particles.geometry.getAttribute('position') as THREE.BufferAttribute;
    const { speed, base } = this.particleData;
    const arr = pos.array as Float32Array;
    for (let i = 0; i < speed.length; i++) {
      const iy = i * 3 + 1;
      arr[iy] += speed[i] * dt;
      arr[i * 3] += Math.sin(t * 0.4 + base[i]) * dt * 0.25;
      if (arr[iy] > 27) {
        arr[iy] = -1;
      }
    }
    pos.needsUpdate = true;
    (this.particles.material as THREE.PointsMaterial).opacity = 0.55 + Math.sin(t * 0.8) * 0.12;
  }

  /* ================= LIFECYCLE ================= */
  setPaused(p: boolean) {
    this.running = !p;
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    this.audio.dispose();
    this.composer?.dispose();
    this.scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
    });
    disposeAll();
    if (this.renderer) {
      this.renderer.domElement.removeEventListener('wheel', this.onWheel);
      this.renderer.domElement.removeEventListener('pointerdown', this.onPointerDown);
      this.renderer.dispose();
      this.renderer.domElement.remove();
    }
  }
}
