/* =========================================================================
   CONFIGURATION — everything important is tweakable from here
   ========================================================================= */

export type Quality = 'low' | 'medium' | 'high';

export type RoomId =
  | 'hub'
  | 'about'
  | 'projects'
  | 'skills'
  | 'experience'
  | 'contact'
  | 'secret';

export const CONFIG = {
  /* ---- ASSETS (easy to swap) ---- */
  // Drop a .glb / .gltf URL here to replace the built-in procedural avatar.
  characterModelUrl: '' as string,
  characterModelScale: 1,

  /* ---- IDENTITY ---- */
  brand: 'AURUM',
  brandSub: 'VIRTUAL WORLD',
  owner: 'ARKAN NOVA',

  /* ---- MOVEMENT ---- */
  characterSpeed: 7.2,
  runSpeed: 13.5,
  acceleration: 12,
  deceleration: 14,
  turnSpeed: 11,
  jumpForce: 9.2,
  gravity: 26,

  /* ---- CAMERA ---- */
  cameraSmoothness: 3.6, // higher = snappier (used with delta time)
  cameraDistance: 9.5,
  cameraRunDistance: 12.4,
  cameraHeight: 4.4,
  cameraLookHeight: 1.7,
  cameraFov: 55,

  /* ---- COLORS ---- */
  goldColor: 0xd4af37,
  goldLight: 0xf5d76e,
  goldSoft: 0xe5c158,
  goldDeep: 0xb8860b,
  goldDark: 0xc9a227,
  backgroundColor: 0x050505,
  whiteColor: 0xf5f5f5,

  /* ---- WORLD ---- */
  hubRadius: 21,
  roomRadius: 19,
  roomDistance: 58,
  walkwayWidth: 6.4,
  interactDistance: 4.6,
  proximityDistance: 9,

  /* ---- FX ---- */
  particleCount: { low: 260, medium: 900, high: 2200 } as Record<Quality, number>,
  bloom: { low: false, medium: true, high: true } as Record<Quality, boolean>,
  shadows: { low: false, medium: false, high: true } as Record<Quality, boolean>,
  pixelRatio: { low: 1, medium: 1.25, high: 1.75 } as Record<Quality, number>,
  fogDensity: 0.0125,
  graphicsQuality: 'high' as Quality,
};

export const GOLD_CSS = '#d4af37';

export type RoomDef = {
  id: RoomId;
  name: string;
  tag: string;
  icon: string;
  angle: number; // radians around the hub
  center: [number, number];
  radius: number;
  hidden?: boolean;
};

const R = CONFIG.roomDistance;
const pos = (angleDeg: number, dist = R): [number, number] => {
  const a = (angleDeg * Math.PI) / 180;
  return [Math.cos(a) * dist, Math.sin(a) * dist];
};

export const ROOMS: RoomDef[] = [
  {
    id: 'hub',
    name: 'MAIN HUB',
    tag: 'CENTRAL NEXUS',
    icon: '◈',
    angle: 0,
    center: [0, 0],
    radius: CONFIG.hubRadius,
  },
  {
    id: 'about',
    name: 'ABOUT',
    tag: 'DIGITAL MUSEUM',
    icon: '❖',
    angle: 90,
    center: pos(90),
    radius: CONFIG.roomRadius,
  },
  {
    id: 'projects',
    name: 'PROJECTS',
    tag: 'GALLERY WING',
    icon: '▣',
    angle: 30,
    center: pos(30),
    radius: CONFIG.roomRadius,
  },
  {
    id: 'skills',
    name: 'SKILLS',
    tag: 'RESEARCH LAB',
    icon: '⬢',
    angle: -30,
    center: pos(-30),
    radius: CONFIG.roomRadius,
  },
  {
    id: 'experience',
    name: 'EXPERIENCE',
    tag: 'TIMELINE VAULT',
    icon: '◇',
    angle: -90,
    center: pos(-90),
    radius: CONFIG.roomRadius,
  },
  {
    id: 'contact',
    name: 'CONTACT',
    tag: 'CONTROL CENTER',
    icon: '◎',
    angle: -150,
    center: pos(-150),
    radius: CONFIG.roomRadius,
  },
  {
    id: 'secret',
    name: 'SECRET',
    tag: 'CLASSIFIED SECTOR',
    icon: '✦',
    angle: 150,
    center: pos(150, R + 6),
    radius: 15,
    hidden: true,
  },
];

export const roomById = (id: RoomId) => ROOMS.find((r) => r.id === id)!;
